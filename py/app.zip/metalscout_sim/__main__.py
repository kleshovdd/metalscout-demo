"""Запуск симулятора: python -m metalscout_sim --vehicle drone|rover."""

from __future__ import annotations

import argparse

from metalscout_sim.server import SimOptions, Simulator

# Открытое поле в Подмосковье — точка старта по умолчанию.
DEFAULT_HOME = "55.70590,37.37030"


def main() -> None:
    p = argparse.ArgumentParser(description="Симулятор устройства MetalScout (ArduPilot + металлоискатель)")
    p.add_argument("--vehicle", choices=["drone", "rover"], default="drone")
    p.add_argument("--home", default=DEFAULT_HOME, help="точка старта: широта,долгота")
    p.add_argument("--home-alt", type=float, default=180.0, help="высота точки старта над морем, м")
    p.add_argument("--target", default="udpout:127.0.0.1:14550", help="куда слать MAVLink")
    p.add_argument("--speedup", type=float, default=1.0, help="ускорение времени 0.1–20")
    p.add_argument("--seed", type=int, default=7, help="зерно случайного мира")
    p.add_argument("--control-port", type=int, default=8711, help="HTTP-пульт симулятора")
    a = p.parse_args()
    lat_s, lon_s = a.home.split(",")
    Simulator(
        SimOptions(
            vehicle=a.vehicle,
            home_lat=float(lat_s),
            home_lon=float(lon_s),
            home_alt=a.home_alt,
            target=a.target,
            speedup=a.speedup,
            seed=a.seed,
            control_port=a.control_port,
        )
    ).run()


if __name__ == "__main__":
    main()
