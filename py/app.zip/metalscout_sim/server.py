"""Симулятор устройства: аппарат ArduPilot + плата металлоискателя на одном MAVLink-канале.

Снаружи выглядит как настоящий аппарат за радиомодемом: шлёт телеметрию на UDP-порт
наземной станции и принимает от неё команды. Плюс небольшой HTTP-«пульт» для того, что
в жизни делает человек руками: поменять батарею, уронить связь, потерять RTK.
"""

from __future__ import annotations

import json
import math
import os
import queue
import random
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

os.environ.setdefault("MAVLINK20", "1")

from pymavlink import mavutil

from metalscout_protocol import (
    CMD_GROUND_BALANCE,
    CMD_SET_SENSITIVITY,
    SAMPLE_NAME,
    SAMPLE_RATE_HZ,
    SENSOR_COMPONENT_ID,
    STATUS_BALANCED,
    STATUS_NAME,
    STATUS_OK,
)
from metalscout_sim.vehicle import (
    GPS_FIX_TYPE,
    GpsQuality,
    MissionItem,
    Vehicle,
    VehicleConfig,
)
from metalscout_sim.world import World

ml = mavutil.mavlink

DEFAULT_INTERVALS: dict[str, float] = {
    "HEARTBEAT": 1.0,
    "GLOBAL_POSITION_INT": 0.1,
    "ATTITUDE": 0.1,
    "GPS_RAW_INT": 0.5,
    "SYS_STATUS": 1.0,
    "BATTERY_STATUS": 1.0,
    "VFR_HUD": 0.5,
    "DISTANCE_SENSOR": 0.1,
    "MISSION_CURRENT": 1.0,
    "SYSTEM_TIME": 1.0,
    "HOME_POSITION": 5.0,
}


@dataclass
class SimOptions:
    vehicle: str
    home_lat: float
    home_lon: float
    home_alt: float
    target: str
    speedup: float
    seed: int
    control_port: int


@dataclass
class _Upload:
    count: int
    items: dict[int, MissionItem]
    next_seq: int
    last_request: float


class Simulator:
    def __init__(self, opts: SimOptions) -> None:
        self.opts = opts
        self.rng = random.Random(opts.seed)
        self.world = World(opts.seed)
        cfg = (
            VehicleConfig.drone(opts.home_lat, opts.home_lon)
            if opts.vehicle == "drone"
            else VehicleConfig.rover(opts.home_lat, opts.home_lon)
        )
        self.vehicle = Vehicle(cfg, self.world.terrain_m, self.rng)
        self.conn: Any = mavutil.mavlink_connection(
            opts.target, source_system=1, source_component=1, autoreconnect=True
        )
        self.sensor_mav: Any = ml.MAVLink(self.conn, srcSystem=1, srcComponent=SENSOR_COMPONENT_ID)
        self.speedup = max(0.1, min(20.0, opts.speedup))
        self.sim_time = 0.0
        self.boot_time = 0.0
        self.intervals = dict(DEFAULT_INTERVALS)
        self.next_send: dict[str, float] = {}
        self.next_sample = 0.0
        self.next_sensor_status = 0.0
        self.upload: _Upload | None = None
        self.link_down_until = 0.0
        self.powered = True
        self.power_on_at = 0.0
        self.ground_rejection = 1.0
        self.sensitivity = 6.0
        self.actions: queue.Queue[tuple[str, dict[str, Any]]] = queue.Queue()
        self.snapshot: dict[str, Any] = {}
        self.lock = threading.Lock()

    # ---------- время ----------
    def boot_ms(self) -> int:
        return int((self.sim_time - self.boot_time) * 1000)

    def link_up(self) -> bool:
        return self.powered and time.monotonic() >= self.link_down_until

    # ---------- главный цикл ----------
    def run(self) -> None:
        self._start_control_server()
        last = time.monotonic()
        while True:
            now = time.monotonic()
            self.tick(now - last, now)
            last = now
            time.sleep(0.01)

    def tick(self, real_dt: float, now: float) -> None:
        """Один шаг: принять команды, продвинуть физику на real_dt × ускорение, отправить телеметрию.

        Цикл `run` зовёт его каждые ~10 мс; встраивающий код (демо в браузере) — по своему таймеру.
        """
        self._process_actions()
        self._receive()
        remaining = real_dt * self.speedup
        while remaining > 1e-6:
            dt = min(0.05, remaining)
            remaining -= dt
            self.sim_time += dt
            if self.powered:
                self.vehicle.step(dt, self._gcs_clock())
                self._telemetry()
                self._sensor()
        if not self.powered and now >= self.power_on_at:
            self._power_on()
        self._retry_upload(now)
        self._update_snapshot()

    def _gcs_clock(self) -> float:
        # Таймаут связи с наземной станцией считаем в реальном времени, как в жизни.
        return time.monotonic()

    # ---------- приём ----------
    def _receive(self) -> None:
        while True:
            msg = self.conn.recv_match(blocking=False)
            if msg is None:
                return
            if not self.link_up():
                continue
            self._handle(msg)

    def _handle(self, msg: Any) -> None:
        kind = msg.get_type()
        v = self.vehicle
        if kind == "HEARTBEAT":
            if msg.type == ml.MAV_TYPE_GCS:
                v.last_gcs_heartbeat = time.monotonic()
            return
        target_comp = getattr(msg, "target_component", 0)
        if kind == "COMMAND_LONG":
            if target_comp == SENSOR_COMPONENT_ID:
                self._sensor_command(msg)
            elif target_comp in (0, 1):
                self._command(msg)
            return
        if target_comp == SENSOR_COMPONENT_ID:
            return
        if kind == "SET_MODE":
            ok = v.set_mode(int(msg.custom_mode))
            self._ack(ml.MAV_CMD_DO_SET_MODE, ok)
        elif kind == "MISSION_COUNT":
            self.upload = _Upload(int(msg.count), {}, 0, 0.0)
            if msg.count == 0:
                v.s.mission = []
                self._mission_ack(ml.MAV_MISSION_ACCEPTED)
                self.upload = None
            else:
                self._request_item(0)
        elif kind in ("MISSION_ITEM_INT", "MISSION_ITEM"):
            self._mission_item(msg, kind == "MISSION_ITEM_INT")
        elif kind == "MISSION_REQUEST_LIST":
            self.conn.mav.mission_count_send(msg.get_srcSystem(), msg.get_srcComponent(), len(v.s.mission), 0)
        elif kind in ("MISSION_REQUEST_INT", "MISSION_REQUEST"):
            self._send_item(int(msg.seq), msg.get_srcSystem(), msg.get_srcComponent())
        elif kind == "MISSION_CLEAR_ALL":
            v.s.mission = []
            v.s.seq = 0
            self._mission_ack(ml.MAV_MISSION_ACCEPTED)
        elif kind == "MISSION_SET_CURRENT":
            if v.set_current(int(msg.seq)):
                self.conn.mav.mission_current_send(v.s.seq)
        elif kind == "SET_POSITION_TARGET_GLOBAL_INT":
            v.goto(msg.lat_int / 1e7, msg.lon_int / 1e7, float(msg.alt))

    def _command(self, msg: Any) -> None:
        v = self.vehicle
        cmd = int(msg.command)
        ok = False
        if cmd == ml.MAV_CMD_COMPONENT_ARM_DISARM:
            ok, reason = v.arm(msg.param1 > 0.5)
            if not ok and reason:
                v.text(ml.MAV_SEVERITY_CRITICAL, reason)
        elif cmd == ml.MAV_CMD_DO_SET_MODE:
            ok = v.set_mode(int(msg.param2))
        elif cmd == ml.MAV_CMD_NAV_TAKEOFF:
            ok = v.takeoff(float(msg.param7))
        elif cmd == ml.MAV_CMD_MISSION_START:
            ok = v.set_mode(3 if v.is_copter else 10)
        elif cmd == ml.MAV_CMD_NAV_RETURN_TO_LAUNCH:
            ok = v.set_mode(6 if v.is_copter else 11)
        elif cmd == ml.MAV_CMD_NAV_LAND:
            ok = v.set_mode(9) if v.is_copter else v.set_mode(4)
        elif cmd == ml.MAV_CMD_DO_SET_MISSION_CURRENT:
            ok = v.set_current(int(msg.param1))
        elif cmd == ml.MAV_CMD_SET_MESSAGE_INTERVAL:
            ok = self._set_interval(int(msg.param1), float(msg.param2))
        elif cmd in (ml.MAV_CMD_REQUEST_MESSAGE, ml.MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES):
            wanted = int(msg.param1) if cmd == ml.MAV_CMD_REQUEST_MESSAGE else 148
            ok = self._send_requested(wanted)
        elif cmd == ml.MAV_CMD_GET_HOME_POSITION:
            ok = self._send_requested(ml.MAVLINK_MSG_ID_HOME_POSITION)
        else:
            self._ack(cmd, False, ml.MAV_RESULT_UNSUPPORTED)
            return
        self._ack(cmd, ok)

    def _ack(self, cmd: int, ok: bool, result: int | None = None) -> None:
        if result is None:
            result = ml.MAV_RESULT_ACCEPTED if ok else ml.MAV_RESULT_DENIED
        self.conn.mav.command_ack_send(cmd, result)

    def _set_interval(self, msg_id: int, interval_us: float) -> bool:
        entry = ml.mavlink_map.get(msg_id)
        if entry is None:
            return False
        name = entry.msgname
        if interval_us < 0:
            self.intervals.pop(name, None)
        elif interval_us > 0:
            self.intervals[name] = max(0.02, interval_us / 1e6)
        else:
            self.intervals[name] = DEFAULT_INTERVALS.get(name, 1.0)
        return True

    def _send_requested(self, msg_id: int) -> bool:
        if msg_id == ml.MAVLINK_MSG_ID_AUTOPILOT_VERSION:
            caps = (
                ml.MAV_PROTOCOL_CAPABILITY_MISSION_INT
                | ml.MAV_PROTOCOL_CAPABILITY_COMMAND_INT
                | ml.MAV_PROTOCOL_CAPABILITY_MAVLINK2
                | ml.MAV_PROTOCOL_CAPABILITY_SET_POSITION_TARGET_GLOBAL_INT
            )
            version = (4 << 24) | (6 << 16) | (0 << 8) | 255
            self.conn.mav.autopilot_version_send(
                caps, version, 0, 0, 0, [0] * 8, [0] * 8, [0] * 8, 0x1209, 0x5741, 0
            )
            return True
        if msg_id == ml.MAVLINK_MSG_ID_HOME_POSITION:
            self._send("HOME_POSITION")
            return True
        name_entry = ml.mavlink_map.get(msg_id)
        if name_entry is not None and name_entry.msgname in DEFAULT_INTERVALS:
            self._send(name_entry.msgname)
            return True
        return False

    # ---------- миссия ----------
    def _request_item(self, seq: int) -> None:
        if self.upload is None:
            return
        self.upload.last_request = time.monotonic()
        self.conn.mav.mission_request_int_send(255, 190, seq, 0)

    def _retry_upload(self, now: float) -> None:
        up = self.upload
        if up is not None and now - up.last_request > 1.0:
            self._request_item(up.next_seq)

    def _mission_item(self, msg: Any, is_int: bool) -> None:
        up = self.upload
        if up is None:
            return
        seq = int(msg.seq)
        if seq != up.next_seq:
            self._request_item(up.next_seq)
            return
        lat = msg.x / 1e7 if is_int else float(msg.x)
        lon = msg.y / 1e7 if is_int else float(msg.y)
        up.items[seq] = MissionItem(
            seq,
            int(msg.command),
            int(msg.frame),
            float(msg.param1),
            float(msg.param2),
            float(msg.param3),
            float(msg.param4),
            lat,
            lon,
            float(msg.z),
        )
        up.next_seq += 1
        if up.next_seq < up.count:
            self._request_item(up.next_seq)
            return
        items = [up.items[i] for i in range(up.count)]
        cfg = self.vehicle.cfg
        items[0] = MissionItem(0, 16, 0, 0, 0, 0, 0, cfg.home_lat, cfg.home_lon, 0)
        self.vehicle.s.mission = items
        self.vehicle.s.seq = 1 if len(items) > 1 else 0
        self.upload = None
        self._mission_ack(ml.MAV_MISSION_ACCEPTED)
        self.vehicle.text(ml.MAV_SEVERITY_INFO, f"Flight plan received ({len(items)} items)")

    def _mission_ack(self, result: int) -> None:
        self.conn.mav.mission_ack_send(255, 190, result, 0)

    def _send_item(self, seq: int, sysid: int, compid: int) -> None:
        mission = self.vehicle.s.mission
        if not 0 <= seq < len(mission):
            self.conn.mav.mission_ack_send(sysid, compid, ml.MAV_MISSION_INVALID_SEQUENCE, 0)
            return
        it = mission[seq]
        self.conn.mav.mission_item_int_send(
            sysid,
            compid,
            it.seq,
            it.frame,
            it.command,
            1 if seq == self.vehicle.s.seq else 0,
            1,
            it.param1,
            it.param2,
            it.param3,
            it.param4,
            int(it.lat * 1e7),
            int(it.lon * 1e7),
            it.alt,
            0,
        )

    # ---------- телеметрия ----------
    def _telemetry(self) -> None:
        v = self.vehicle
        s = v.s
        for seq in s.reached:
            if self.link_up():
                self.conn.mav.mission_item_reached_send(seq)
        s.reached.clear()
        prev_seq = getattr(self, "_last_seq", None)
        if prev_seq != s.seq and self.link_up():
            self.conn.mav.mission_current_send(s.seq)
            self._last_seq = s.seq
        for severity, text in s.texts:
            if self.link_up():
                self.conn.mav.statustext_send(severity, text.encode()[:50])
        s.texts.clear()
        for name, interval in self.intervals.items():
            if not v.is_copter and name == "DISTANCE_SENSOR":
                continue
            due = self.next_send.get(name, 0.0)
            if self.sim_time >= due:
                self.next_send[name] = self.sim_time + interval
                if self.link_up():
                    self._send(name)

    def _send(self, name: str) -> None:
        v = self.vehicle
        s = v.s
        mav = self.conn.mav
        t_ms = self.boot_ms()
        nE, nN = v.gps_noise()
        lat, lon = v.to_latlon(s.east + nE, s.north + nN)
        ground = v.ground_alt()
        amsl = self.opts.home_alt + ground + s.alt
        if name == "HEARTBEAT":
            base = ml.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED
            if s.armed:
                base |= ml.MAV_MODE_FLAG_SAFETY_ARMED
            mav_type = ml.MAV_TYPE_QUADROTOR if v.is_copter else ml.MAV_TYPE_GROUND_ROVER
            status = ml.MAV_STATE_ACTIVE if s.armed else ml.MAV_STATE_STANDBY
            mav.heartbeat_send(mav_type, ml.MAV_AUTOPILOT_ARDUPILOTMEGA, base, v.custom_mode(), status)
            self.sensor_mav.heartbeat_send(
                ml.MAV_TYPE_ONBOARD_CONTROLLER, ml.MAV_AUTOPILOT_INVALID, 0, 0, ml.MAV_STATE_ACTIVE
            )
        elif name == "GLOBAL_POSITION_INT":
            hdg = int(math.degrees(s.yaw) * 100) % 36000
            mav.global_position_int_send(
                t_ms,
                int(lat * 1e7),
                int(lon * 1e7),
                int(amsl * 1000),
                int((ground + s.alt) * 1000),
                int(s.vn * 100),
                int(s.ve * 100),
                int(-s.vz * 100),
                hdg,
            )
        elif name == "ATTITUDE":
            roll = max(-0.4, min(0.4, s.ve * 0.05 * math.cos(s.yaw) - s.vn * 0.05 * math.sin(s.yaw)))
            pitch = -0.05 * math.hypot(s.ve, s.vn)
            yaw = s.yaw if s.yaw <= math.pi else s.yaw - 2 * math.pi
            mav.attitude_send(t_ms, roll, pitch, yaw, 0.0, 0.0, s.yaw_rate)
        elif name == "GPS_RAW_INT":
            fix = GPS_FIX_TYPE[v.gps_quality]
            eph = {6: 2, 5: 20, 3: 120, 0: 9999}[fix]
            mav.gps_raw_int_send(
                int(self.sim_time * 1e6),
                fix,
                int(lat * 1e7),
                int(lon * 1e7),
                int(amsl * 1000),
                eph,
                eph,
                int(math.hypot(s.ve, s.vn) * 100),
                int(math.degrees(s.yaw) * 100) % 36000,
                {6: 24, 5: 21, 3: 11, 0: 2}[fix],
            )
        elif name in ("SYS_STATUS", "BATTERY_STATUS"):
            cells = 6 if v.is_copter else 13
            volts = cells * (3.45 + 0.75 * s.battery_pct / 100.0)
            current = (18.0 if v.is_copter else 9.0) if s.armed else 0.4
            if name == "SYS_STATUS":
                mav.sys_status_send(
                    0, 0, 0, 300, int(volts * 1000), int(current * 100), int(s.battery_pct), 0, 0, 0, 0, 0, 0
                )
            else:
                cell_mv = [int(volts * 1000 / cells)] * cells + [65535] * (10 - min(cells, 10))
                mav.battery_status_send(
                    0,
                    ml.MAV_BATTERY_FUNCTION_ALL,
                    ml.MAV_BATTERY_TYPE_LIPO if v.is_copter else ml.MAV_BATTERY_TYPE_LION,
                    2500,
                    cell_mv[:10],
                    int(current * 100),
                    -1,
                    -1,
                    int(s.battery_pct),
                )
        elif name == "VFR_HUD":
            mav.vfr_hud_send(
                0.0,
                math.hypot(s.ve, s.vn),
                int(math.degrees(s.yaw)) % 360,
                60 if s.armed else 0,
                amsl,
                -s.vz,
            )
        elif name == "DISTANCE_SENSOR":
            _, _, coil_h = v.coil_position()
            reading = max(0.05, coil_h + self.rng.gauss(0, 0.015))
            mav.distance_sensor_send(
                t_ms,
                5,
                1200,
                int(reading * 100),
                ml.MAV_DISTANCE_SENSOR_LASER,
                0,
                ml.MAV_SENSOR_ROTATION_PITCH_270,
                0,
            )
        elif name == "MISSION_CURRENT":
            mav.mission_current_send(s.seq)
        elif name == "SYSTEM_TIME":
            mav.system_time_send(int(time.time() * 1e6), t_ms)
        elif name == "HOME_POSITION":
            hlat, hlon = v.to_latlon(0.0, 0.0)
            mav.home_position_send(
                int(hlat * 1e7),
                int(hlon * 1e7),
                int(self.opts.home_alt * 1000),
                0,
                0,
                0,
                [1, 0, 0, 0],
                0,
                0,
                0,
            )

    # ---------- металлоискатель ----------
    def _sensor(self) -> None:
        if self.sim_time >= self.next_sensor_status:
            self.next_sensor_status = self.sim_time + 1.0
            status = STATUS_OK | (STATUS_BALANCED if self.ground_rejection < 1.0 else 0)
            if self.link_up():
                self.sensor_mav.named_value_int_send(self.boot_ms(), STATUS_NAME.encode(), status)
        if self.sim_time < self.next_sample:
            return
        self.next_sample = self.sim_time + 1.0 / SAMPLE_RATE_HZ
        v = self.vehicle
        e, n, h = v.coil_position()
        reading = self.world.read(e, n, h, v.cfg.coil_radius_m, self.ground_rejection, self.rng)
        gain = self.sensitivity / 6.0
        signal = reading.signal * gain
        # Помехи от регуляторов моторов дрона — редкие выбросы.
        if v.is_copter and v.s.armed and self.rng.random() < 0.004:
            signal += self.rng.uniform(0.3, 1.2)
        if self.link_up():
            self.sensor_mav.debug_vect_send(
                SAMPLE_NAME.encode(),
                self.boot_ms() * 1000,
                float(signal),
                float(reading.target_id),
                float(reading.ground),
            )

    def _sensor_command(self, msg: Any) -> None:
        cmd = int(msg.command)
        if cmd == CMD_GROUND_BALANCE:
            self.ground_rejection = 0.06
            result = ml.MAV_RESULT_ACCEPTED
        elif cmd == CMD_SET_SENSITIVITY and 1 <= msg.param1 <= 10:
            self.sensitivity = float(msg.param1)
            result = ml.MAV_RESULT_ACCEPTED
        else:
            result = ml.MAV_RESULT_UNSUPPORTED
        self.sensor_mav.command_ack_send(cmd, result)

    # ---------- «руки человека» ----------
    def _power_on(self) -> None:
        self.powered = True
        self.boot_time = self.sim_time  # время контроллера начинается с нуля, как после включения
        self.next_send.clear()
        self.vehicle.text(ml.MAV_SEVERITY_INFO, "ArduPilot boot complete")

    def _process_actions(self) -> None:
        while True:
            try:
                action, args = self.actions.get_nowait()
            except queue.Empty:
                return
            v = self.vehicle
            if action == "swap_battery" and v.swap_battery():
                self.powered = False
                self.power_on_at = time.monotonic() + 3.0
                self.ground_rejection = 1.0  # после включения детектор снова не сбалансирован
            elif action == "speedup":
                self.speedup = max(0.1, min(20.0, float(args.get("value", 1.0))))
            elif action == "link_down":
                self.link_down_until = time.monotonic() + float(args.get("seconds", 10))
            elif action == "gps":
                quality = str(args.get("quality", "rtk_fixed"))
                if quality in ("rtk_fixed", "rtk_float", "3d", "none"):
                    q: GpsQuality = quality  # type: ignore[assignment]
                    v.gps_quality = q

    def _update_snapshot(self) -> None:
        v = self.vehicle
        lat, lon = v.to_latlon(v.s.east, v.s.north)
        snap = {
            "vehicle": self.opts.vehicle,
            "speedup": self.speedup,
            "powered": self.powered,
            "link_up": self.link_up(),
            "gps": v.gps_quality,
            "battery_pct": round(v.s.battery_pct, 1),
            "mode": v.s.mode,
            "armed": v.s.armed,
            "lat": lat,
            "lon": lon,
            "sim_time": round(self.sim_time, 1),
        }
        with self.lock:
            self.snapshot = snap

    def truth(self) -> list[dict[str, Any]]:
        out = []
        for obj in self.world.objects:
            lat, lon = self.vehicle.to_latlon(obj.east, obj.north)
            out.append(
                {
                    "id": obj.id,
                    "kind": obj.kind.name,
                    "lat": lat,
                    "lon": lon,
                    "depth_m": obj.depth_m,
                    "target_id": obj.target_id,
                }
            )
        return out

    def _start_control_server(self) -> None:
        sim = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format: str, *args: Any) -> None:
                return

            def _reply(self, code: int, body: Any) -> None:
                data = json.dumps(body, ensure_ascii=False).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self) -> None:
                if self.path == "/state":
                    with sim.lock:
                        self._reply(200, sim.snapshot)
                elif self.path == "/truth":
                    self._reply(200, sim.truth())
                else:
                    self._reply(404, {"error": "not found"})

            def do_POST(self) -> None:
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length) if length else b"{}"
                try:
                    args = json.loads(raw or b"{}")
                except json.JSONDecodeError:
                    self._reply(400, {"error": "bad json"})
                    return
                action = self.path.strip("/")
                if action not in ("swap_battery", "speedup", "link_down", "gps"):
                    self._reply(404, {"error": "unknown action"})
                    return
                sim.actions.put((action, args if isinstance(args, dict) else {}))
                self._reply(202, {"ok": True})

        server = ThreadingHTTPServer(("127.0.0.1", self.opts.control_port), Handler)
        threading.Thread(target=server.serve_forever, daemon=True, name="sim-control").start()
