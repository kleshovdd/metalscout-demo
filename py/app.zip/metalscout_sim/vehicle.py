"""Модель аппарата с поведением ArduPilot: режимы, миссия, физика, батарея, failsafe.

Это не «заглушка программы», а эмуляция прошивки на том конце провода. Поведение повторяет
ArduPilot Copter / Rover в том объёме, который использует MetalScout.
"""

from __future__ import annotations

import math
import random
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Literal

from metalscout_protocol.ardupilot import VehicleFamily, mode_name, mode_number

EARTH_R = 6378137.0

# MAV_CMD
CMD_NAV_WAYPOINT = 16
CMD_NAV_RTL = 20
CMD_NAV_LAND = 21
CMD_NAV_TAKEOFF = 22
CMD_DO_CHANGE_SPEED = 178

GpsQuality = Literal["rtk_fixed", "rtk_float", "3d", "none"]
GPS_FIX_TYPE: dict[GpsQuality, int] = {"rtk_fixed": 6, "rtk_float": 5, "3d": 3, "none": 0}
GPS_NOISE_M: dict[GpsQuality, float] = {"rtk_fixed": 0.012, "rtk_float": 0.15, "3d": 1.2, "none": 0}
# Ошибка GPS не прыгает от отсчёта к отсчёту, а медленно «плывёт»: время корреляции, с.
GPS_DRIFT_TAU_S: dict[GpsQuality, float] = {"rtk_fixed": 3.0, "rtk_float": 12.0, "3d": 40.0, "none": 40.0}
GPS_JITTER_RATIO = 0.04  # быстрый шум поверх дрейфа — доля от общей ошибки


@dataclass
class MissionItem:
    seq: int
    command: int
    frame: int
    param1: float
    param2: float
    param3: float
    param4: float
    lat: float
    lon: float
    alt: float


@dataclass
class VehicleConfig:
    family: VehicleFamily
    home_lat: float
    home_lon: float
    cruise_speed: float  # м/с, WPNAV_SPEED / CRUISE_SPEED
    rtl_speed: float
    rtl_alt: float  # м, только дрон
    accel: float  # м/с²
    coil_drop_m: float  # дрон: насколько катушка ниже рамы
    coil_forward_m: float  # машинка: вынос катушки вперёд
    coil_radius_m: float
    endurance_min: float  # минут на 100 % батареи при работе
    batt_low_pct: float = 20.0  # BATT_LOW → RTL
    batt_crit_pct: float = 8.0  # BATT_CRT → LAND (дрон) / HOLD (машинка)
    wp_radius_m: float = 0.15
    gcs_timeout_s: float = 5.0

    @staticmethod
    def drone(lat: float, lon: float) -> VehicleConfig:
        return VehicleConfig(
            family="copter",
            home_lat=lat,
            home_lon=lon,
            cruise_speed=1.0,
            rtl_speed=3.0,
            rtl_alt=4.0,
            accel=1.5,
            coil_drop_m=1.4,
            coil_forward_m=0.0,
            coil_radius_m=0.13,
            endurance_min=24.0,
        )

    @staticmethod
    def rover(lat: float, lon: float) -> VehicleConfig:
        return VehicleConfig(
            family="rover",
            home_lat=lat,
            home_lon=lon,
            cruise_speed=1.0,
            rtl_speed=1.5,
            rtl_alt=0.0,
            accel=0.8,
            coil_drop_m=0.0,
            coil_forward_m=1.1,
            coil_radius_m=0.2,
            endurance_min=180.0,
            batt_low_pct=15.0,
            batt_crit_pct=5.0,
            wp_radius_m=0.25,
        )


@dataclass
class VehicleState:
    east: float = 0.0
    north: float = 0.0
    alt: float = 0.0  # высота рамы над грунтом под аппаратом (дрон), м
    ve: float = 0.0
    vn: float = 0.0
    vz: float = 0.0
    yaw: float = 0.0  # рад, 0 = север, по часовой
    yaw_rate: float = 0.0
    armed: bool = False
    landed: bool = True
    mode: str = "LOITER"
    battery_pct: float = 100.0
    mission: list[MissionItem] = field(default_factory=list)
    seq: int = 0
    speed: float = 1.0
    target: tuple[float, float, float] | None = None  # east, north, alt
    reached: list[int] = field(default_factory=list)  # события MISSION_ITEM_REACHED
    texts: list[tuple[int, str]] = field(default_factory=list)  # события STATUSTEXT
    drift_e: float = 0.0
    drift_n: float = 0.0


class Vehicle:
    def __init__(
        self, cfg: VehicleConfig, terrain: Callable[[float, float], float], rng: random.Random
    ) -> None:
        self.cfg = cfg
        self.terrain = terrain
        self.rng = rng
        self.s = VehicleState(speed=cfg.cruise_speed)
        self.s.mode = "LOITER" if cfg.family == "copter" else "HOLD"
        self.gps_quality: GpsQuality = "rtk_fixed"
        self.gps_err = (0.0, 0.0)
        self.last_gcs_heartbeat: float | None = None
        self.failsafe_gcs = False

    # ---------- координаты ----------
    def to_latlon(self, east: float, north: float) -> tuple[float, float]:
        lat0 = math.radians(self.cfg.home_lat)
        lat = self.cfg.home_lat + math.degrees(north / EARTH_R)
        lon = self.cfg.home_lon + math.degrees(east / (EARTH_R * math.cos(lat0)))
        return lat, lon

    def to_local(self, lat: float, lon: float) -> tuple[float, float]:
        lat0 = math.radians(self.cfg.home_lat)
        north = math.radians(lat - self.cfg.home_lat) * EARTH_R
        east = math.radians(lon - self.cfg.home_lon) * EARTH_R * math.cos(lat0)
        return east, north

    @property
    def is_copter(self) -> bool:
        return self.cfg.family == "copter"

    def custom_mode(self) -> int:
        return mode_number(self.cfg.family, self.s.mode)

    def text(self, severity: int, msg: str) -> None:
        self.s.texts.append((severity, msg))

    # ---------- команды ----------
    def set_mode(self, number: int) -> bool:
        name = mode_name(self.cfg.family, number)
        if name.startswith("MODE_"):
            return False
        if name == "AUTO" and not self.s.mission:
            self.text(4, "Mode change to AUTO failed: no mission")
            return False
        self.s.mode = name
        if name == "AUTO":
            self.s.seq = max(self.s.seq, 1)
            self.s.target = None
        if name in ("RTL", "LAND", "LOITER", "BRAKE", "HOLD"):
            self.s.target = None
        return True

    def arm(self, want: bool) -> tuple[bool, str]:
        s = self.s
        if not want:
            if not s.landed and self.is_copter:
                return False, "Disarm: not landed"
            s.armed = False
            return True, ""
        if s.armed:
            return True, ""
        if self.gps_quality == "none":
            return False, "PreArm: GPS: no fix"
        if s.battery_pct < self.cfg.batt_low_pct + 5:
            return False, "PreArm: Battery 1 below minimum arming capacity"
        if self.is_copter and s.mode not in ("GUIDED", "LOITER", "STABILIZE", "ALT_HOLD"):
            return False, f"PreArm: Mode {s.mode} not armable"
        s.armed = True
        self.text(6, "Arming motors")
        return True, ""

    def takeoff(self, alt: float) -> bool:
        s = self.s
        if not self.is_copter or not s.armed or s.mode != "GUIDED":
            return False
        s.landed = False
        s.target = (s.east, s.north, alt)
        return True

    def goto(self, lat: float, lon: float, alt: float) -> bool:
        if self.s.mode != "GUIDED" or not self.s.armed:
            return False
        e, n = self.to_local(lat, lon)
        self.s.target = (e, n, alt if self.is_copter else 0.0)
        return True

    def set_current(self, seq: int) -> bool:
        if not 0 <= seq < len(self.s.mission):
            return False
        self.s.seq = max(1, seq)
        if self.s.mode == "AUTO":
            self.s.target = None
        return True

    def swap_battery(self) -> bool:
        """Пользователь выключил аппарат, поменял батарею и включил снова."""
        if self.s.armed:
            return False
        self.s.battery_pct = 100.0
        self.s.mode = "LOITER" if self.is_copter else "HOLD"
        self.failsafe_gcs = False
        return True

    # ---------- физика ----------
    def step(self, dt: float, now: float) -> None:
        s = self.s
        self._check_failsafes(now)
        self._drift_gps(dt)
        if s.armed and s.mode == "AUTO":
            self._run_mission()
        target_speed = s.speed
        tgt = s.target
        if s.mode == "RTL":
            target_speed = self.cfg.rtl_speed
            tgt = self._rtl_target()
        elif s.mode == "LAND":
            tgt = (s.east, s.north, -1.0)
        elif s.mode in ("LOITER", "BRAKE", "HOLD") or not s.armed:
            tgt = None

        if self.is_copter:
            self._step_copter(dt, tgt, target_speed)
        else:
            self._step_rover(dt, tgt, target_speed)
        self._drain(dt)

    def _rtl_target(self) -> tuple[float, float, float]:
        s = self.s
        dist = math.hypot(s.east, s.north)
        if self.is_copter:
            if dist > 0.5 and s.alt < self.cfg.rtl_alt - 0.2:
                return (s.east, s.north, self.cfg.rtl_alt)
            if dist > 0.3:
                return (0.0, 0.0, self.cfg.rtl_alt)
            return (0.0, 0.0, -1.0)  # над точкой старта — садимся
        return (0.0, 0.0, 0.0)

    def _run_mission(self) -> None:
        s = self.s
        while s.seq < len(s.mission):
            item = s.mission[s.seq]
            if item.command == CMD_DO_CHANGE_SPEED:
                if item.param2 > 0:
                    s.speed = item.param2
                self._advance()
                continue
            if item.command == CMD_NAV_TAKEOFF:
                if not self.is_copter:
                    self._advance()
                    continue
                s.landed = False
                if s.alt >= item.alt - 0.1:
                    self._advance()
                    continue
                s.target = (s.east, s.north, item.alt)
                return
            if item.command == CMD_NAV_WAYPOINT:
                e, n = self.to_local(item.lat, item.lon)
                s.target = (e, n, item.alt)
                if math.hypot(e - s.east, n - s.north) <= self.cfg.wp_radius_m:
                    self._advance()
                    continue
                return
            if item.command == CMD_NAV_RTL:
                s.reached.append(item.seq)
                s.mode = "RTL"
                s.target = None
                return
            if item.command == CMD_NAV_LAND:
                s.mode = "LAND"
                return
            self._advance()  # неизвестная команда — пропускаем, как ArduPilot
        # Миссия закончилась: висим / стоим.
        s.target = None

    def _advance(self) -> None:
        s = self.s
        s.reached.append(s.seq)
        s.seq += 1

    def _step_copter(self, dt: float, tgt: tuple[float, float, float] | None, speed: float) -> None:
        s = self.s
        if s.landed:
            s.ve = s.vn = s.vz = 0.0
            if tgt is not None and tgt[2] > 0.2 and s.armed:
                s.landed = False
            else:
                return
        # Горизонталь: к цели с ограничением скорости и ускорения.
        if tgt is not None:
            de, dn = tgt[0] - s.east, tgt[1] - s.north
            dist = math.hypot(de, dn)
            want = min(speed, math.sqrt(2 * self.cfg.accel * dist) * 0.9, dist / max(dt, 1e-3))
            we, wn = (de / dist * want, dn / dist * want) if dist > 1e-3 else (0.0, 0.0)
        else:
            we = wn = 0.0
        max_dv = self.cfg.accel * dt
        s.ve += max(-max_dv, min(max_dv, we - s.ve))
        s.vn += max(-max_dv, min(max_dv, wn - s.vn))
        # Ветер и неидеальность регулятора — медленный дрейф ±несколько сантиметров.
        k = math.exp(-dt / 3.0)
        s.drift_e = s.drift_e * k + self.rng.gauss(0, 0.012) * math.sqrt(dt)
        s.drift_n = s.drift_n * k + self.rng.gauss(0, 0.012) * math.sqrt(dt)
        s.east += s.ve * dt + s.drift_e * dt
        s.north += s.vn * dt + s.drift_n * dt
        if math.hypot(s.ve, s.vn) > 0.15:
            want_yaw = math.atan2(s.ve, s.vn)
            dy = (want_yaw - s.yaw + math.pi) % (2 * math.pi) - math.pi
            turn = max(-math.radians(90) * dt, min(math.radians(90) * dt, dy))
            s.yaw = (s.yaw + turn) % (2 * math.pi)
            s.yaw_rate = turn / dt if dt > 0 else 0.0
        else:
            s.yaw_rate = 0.0
        # Вертикаль: следование рельефу по дальномеру (с запаздыванием).
        if tgt is not None and tgt[2] < 0:
            s.vz = -0.6
        elif tgt is not None:
            s.vz = max(-0.8, min(0.8, (tgt[2] - s.alt) * 1.5))
        else:
            s.vz = max(-0.8, min(0.8, (max(s.alt, 0.0) - s.alt) * 1.5))
        ground_before = self.terrain(s.east - s.ve * dt, s.north - s.vn * dt)
        ground_now = self.terrain(s.east, s.north)
        # Рельеф под аппаратом изменился → высота над грунтом изменилась, регулятор догонит.
        s.alt += s.vz * dt - (ground_now - ground_before) * 0.6
        if s.alt <= 0.0 and (tgt is None or tgt[2] < 0 or s.mode in ("LAND", "RTL")):
            s.alt = 0.0
            s.landed = True
            s.ve = s.vn = s.vz = 0.0
            if s.armed and s.mode in ("LAND", "RTL"):
                s.armed = False
                self.text(6, "Disarming motors")
                self.text(6, "Land complete")
        s.alt = max(0.0, s.alt)

    def _step_rover(self, dt: float, tgt: tuple[float, float, float] | None, speed: float) -> None:
        s = self.s
        s.landed = True
        if tgt is None:
            want_speed = 0.0
            turn = 0.0
        else:
            de, dn = tgt[0] - s.east, tgt[1] - s.north
            dist = math.hypot(de, dn)
            want_yaw = math.atan2(de, dn)
            err = (want_yaw - s.yaw + math.pi) % (2 * math.pi) - math.pi
            max_turn = math.radians(70) * dt
            turn = max(-max_turn, min(max_turn, err))
            if abs(err) > math.radians(35):
                want_speed = 0.0  # разворот на месте (skid-steer)
            else:
                want_speed = min(speed, math.sqrt(2 * self.cfg.accel * dist), dist / max(dt, 1e-3))
                want_speed *= math.cos(err)
        s.yaw = (s.yaw + turn) % (2 * math.pi)
        s.yaw_rate = turn / dt if dt > 0 else 0.0
        cur = math.hypot(s.ve, s.vn)
        cur += max(-self.cfg.accel * dt, min(self.cfg.accel * dt, want_speed - cur))
        slip = 1.0 + self.rng.gauss(0, 0.02)
        s.ve = cur * math.sin(s.yaw) * slip
        s.vn = cur * math.cos(s.yaw) * slip
        s.east += s.ve * dt
        s.north += s.vn * dt
        s.alt = 0.0

    def _drain(self, dt: float) -> None:
        s = self.s
        if not s.armed:
            s.battery_pct = max(0.0, s.battery_pct - dt / 3600.0 * 0.5)  # электроника
            return
        per_s = 100.0 / (self.cfg.endurance_min * 60.0)
        moving = math.hypot(s.ve, s.vn)
        factor = 1.0 + 0.15 * moving if self.is_copter else 0.35 + 0.65 * min(1.0, moving)
        s.battery_pct = max(0.0, s.battery_pct - per_s * factor * dt)

    def _check_failsafes(self, now: float) -> None:
        s = self.s
        if not s.armed:
            return
        if s.battery_pct <= self.cfg.batt_crit_pct and s.mode not in ("LAND",):
            if self.is_copter:
                s.mode = "LAND"
                self.text(2, "Battery 1 is critical! Landing")
            elif s.mode != "HOLD":
                s.mode = "HOLD"
                self.text(2, "Battery 1 is critical! Hold")
            return
        if s.battery_pct <= self.cfg.batt_low_pct and s.mode not in ("RTL", "LAND"):
            s.mode = "RTL"
            self.text(3, "Battery 1 is low! Returning to launch")
            return
        if (
            self.last_gcs_heartbeat is not None
            and now - self.last_gcs_heartbeat > self.cfg.gcs_timeout_s
            and s.mode == "AUTO"
        ):
            s.mode = "RTL"
            self.failsafe_gcs = True
            self.text(2, "GCS Failsafe: returning to launch")

    # ---------- измерения для телеметрии ----------
    def ground_alt(self) -> float:
        return self.terrain(self.s.east, self.s.north)

    def coil_position(self) -> tuple[float, float, float]:
        """Положение катушки: восток, север, высота над грунтом."""
        s = self.s
        if self.is_copter:
            return s.east, s.north, max(0.0, s.alt - self.cfg.coil_drop_m)
        e = s.east + self.cfg.coil_forward_m * math.sin(s.yaw)
        n = s.north + self.cfg.coil_forward_m * math.cos(s.yaw)
        return e, n, 0.06 + abs(self.rng.gauss(0, 0.01))

    def _drift_gps(self, dt: float) -> None:
        """Процесс Орнштейна–Уленбека: ошибка с заданным разбросом и медленным дрейфом."""
        sigma = GPS_NOISE_M[self.gps_quality]
        k = math.exp(-dt / GPS_DRIFT_TAU_S[self.gps_quality])
        step = sigma * math.sqrt(1 - k * k)
        e, n = self.gps_err
        self.gps_err = (e * k + self.rng.gauss(0, step), n * k + self.rng.gauss(0, step))

    def gps_noise(self) -> tuple[float, float]:
        jitter = GPS_NOISE_M[self.gps_quality] * GPS_JITTER_RATIO
        e, n = self.gps_err
        return e + self.rng.gauss(0, jitter), n + self.rng.gauss(0, jitter)
