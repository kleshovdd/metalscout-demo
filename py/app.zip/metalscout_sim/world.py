"""Мир симулятора: рельеф, грунт и закопанные предметы, физическая модель сигнала.

Координаты — локальные метры от точки старта (восток, север).
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass


@dataclass(frozen=True)
class ObjectKind:
    name: str
    target_id: tuple[int, int]  # диапазон ID цели, как у VLF-детектора
    size: float  # «электрический размер» относительно монеты
    weight: float  # доля среди предметов


KINDS: tuple[ObjectKind, ...] = (
    ObjectKind("Гвоздь", (4, 12), 0.6, 30),
    ObjectKind("Пробка от бутылки", (12, 18), 1.2, 20),
    ObjectKind("Фольга", (18, 28), 0.4, 15),
    ObjectKind("Золотое кольцо", (32, 42), 0.9, 2),
    ObjectKind("Язычок от банки", (44, 54), 0.8, 12),
    ObjectKind("Монета (никель)", (55, 62), 1.0, 6),
    ObjectKind("Алюминиевая банка", (60, 68), 5.0, 5),
    ObjectKind("Ключи", (66, 74), 2.0, 3),
    ObjectKind("Монета (медь)", (72, 80), 1.0, 6),
    ObjectKind("Монета (серебро)", (84, 92), 1.1, 1),
)


@dataclass(frozen=True)
class BuriedObject:
    id: int
    kind: ObjectKind
    east: float
    north: float
    depth_m: float
    target_id: int


@dataclass(frozen=True)
class SignalReading:
    signal: float
    target_id: float
    ground: float


class World:
    """Предметы, рельеф и грунт вокруг точки старта."""

    CELL = 1.0  # м, сетка для быстрого поиска ближайших предметов

    def __init__(self, seed: int, radius_m: float = 90.0, density_per_m2: float = 0.06) -> None:
        rng = random.Random(seed)
        self._phase = [rng.uniform(0, 2 * math.pi) for _ in range(6)]
        count = int(math.pi * radius_m**2 * density_per_m2)
        weights = [k.weight for k in KINDS]
        objects: list[BuriedObject] = []
        for i in range(count):
            kind = rng.choices(KINDS, weights)[0]
            r = radius_m * math.sqrt(rng.random())
            a = rng.uniform(0, 2 * math.pi)
            depth = min(0.3, abs(rng.gauss(0.0, 0.11)))
            # Ничего прямо под точкой старта: там стоит устройство.
            if r < 4.0:
                continue
            objects.append(
                BuriedObject(
                    id=i,
                    kind=kind,
                    east=r * math.cos(a),
                    north=r * math.sin(a),
                    depth_m=round(depth, 3),
                    target_id=rng.randint(*kind.target_id),
                )
            )
        self.objects = objects
        self._grid: dict[tuple[int, int], list[BuriedObject]] = {}
        for obj in objects:
            self._grid.setdefault(self._cell(obj.east, obj.north), []).append(obj)

    def _cell(self, east: float, north: float) -> tuple[int, int]:
        return (math.floor(east / self.CELL), math.floor(north / self.CELL))

    def terrain_m(self, east: float, north: float) -> float:
        """Высота грунта относительно точки старта: пологие кочки до ±0,4 м."""
        p = self._phase
        return (
            0.25 * math.sin(east / 13.0 + p[0])
            + 0.15 * math.cos(north / 9.0 + p[1])
            + 0.05 * math.sin((east + north) / 3.1 + p[2])
        )

    def mineralization(self, east: float, north: float) -> float:
        """Минерализация грунта 0…1, плавно меняется по полю."""
        p = self._phase
        value = 0.55 + 0.3 * math.sin(east / 21.0 + p[3]) * math.cos(north / 17.0 + p[4])
        value += 0.1 * math.sin((east - north) / 6.0 + p[5])
        return max(0.0, min(1.0, value))

    def nearby(self, east: float, north: float, radius: float) -> list[BuriedObject]:
        cx, cy = self._cell(east, north)
        span = math.ceil(radius / self.CELL)
        found: list[BuriedObject] = []
        for dx in range(-span, span + 1):
            for dy in range(-span, span + 1):
                found.extend(self._grid.get((cx + dx, cy + dy), ()))
        return found

    def read(
        self,
        east: float,
        north: float,
        coil_height_m: float,
        coil_radius_m: float,
        ground_rejection: float,
        rng: random.Random,
    ) -> SignalReading:
        """Сигнал катушки в точке: предметы + грунт + шум.

        Отклик мелкого предмета в ближней зоне катушки ~ (a²/(a² + z² + r²))³:
        он очень быстро падает с высотой, поэтому катушка должна идти низко.
        """
        a2 = coil_radius_m**2
        h = max(0.02, coil_height_m)
        total = 0.0
        best_share = 0.0
        best_tid = 0
        for obj in self.nearby(east, north, 1.5):
            z = h + obj.depth_m
            r2 = (obj.east - east) ** 2 + (obj.north - north) ** 2
            amp = 420.0 * obj.kind.size * (a2 / (a2 + z * z + r2)) ** 3
            total += amp
            if amp > best_share:
                best_share = amp
                best_tid = obj.target_id
        ground = self.mineralization(east, north) * 0.9 * (a2 / (a2 + h * h)) ** 1.5
        signal = total + ground * ground_rejection + abs(rng.gauss(0.0, 0.025))
        if total > 0.25 and best_share / total > 0.6:
            tid = float(max(0, min(99, round(rng.gauss(best_tid, 2.5)))))
        else:
            tid = -1.0
        return SignalReading(signal=signal, target_id=tid, ground=ground)
