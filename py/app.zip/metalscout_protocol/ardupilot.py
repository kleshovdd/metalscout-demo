"""Номера режимов ArduPilot (custom_mode в HEARTBEAT) — Copter и Rover."""

from typing import Literal

VehicleFamily = Literal["copter", "rover"]

COPTER_MODES: dict[str, int] = {
    "STABILIZE": 0,
    "ALT_HOLD": 2,
    "AUTO": 3,
    "GUIDED": 4,
    "LOITER": 5,
    "RTL": 6,
    "LAND": 9,
    "BRAKE": 17,
}

ROVER_MODES: dict[str, int] = {
    "MANUAL": 0,
    "HOLD": 4,
    "LOITER": 5,
    "AUTO": 10,
    "RTL": 11,
    "GUIDED": 15,
    "INITIALISING": 16,
}


def _table(family: VehicleFamily) -> dict[str, int]:
    return COPTER_MODES if family == "copter" else ROVER_MODES


def mode_number(family: VehicleFamily, name: str) -> int:
    return _table(family)[name]


def mode_name(family: VehicleFamily, number: int) -> str:
    for name, value in _table(family).items():
        if value == number:
            return name
    return f"MODE_{number}"
