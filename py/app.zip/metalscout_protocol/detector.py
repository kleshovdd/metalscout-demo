"""Протокол платы датчика металлоискателя (sensor node) поверх MAVLink common.

Плата подключена к порту TELEM2 полётного контроллера. ArduPilot пересылает её сообщения
наземной станции тем же каналом, что и телеметрию, с `sysid` аппарата и своим `compid`.

Сообщения от датчика:

* ``HEARTBEAT`` 1 Гц, ``type = MAV_TYPE_ONBOARD_CONTROLLER``, ``autopilot = MAV_AUTOPILOT_INVALID``.
* ``DEBUG_VECT`` с ``name = SAMPLE_NAME`` — одно измерение, ``SAMPLE_RATE_HZ`` в секунду:
  - ``time_usec`` — время полётного контроллера с момента загрузки (мкс). Плата берёт его из
    ``SYSTEM_TIME``/``TIMESYNC`` контроллера, поэтому сигнал совпадает с позицией без догадок;
  - ``x`` — сила сигнала, условные единицы детектора (≥ 0);
  - ``y`` — ID цели 0–99 (фаза, «тип металла»), ``NO_TARGET_ID`` если цели нет;
  - ``z`` — уровень сигнала грунта (минерализация), условные единицы.
* ``NAMED_VALUE_INT`` с ``name = STATUS_NAME`` — битовая маска состояния, 1 Гц.

Команды датчику (``COMMAND_LONG`` с ``target_component = SENSOR_COMPONENT_ID``):

* ``CMD_GROUND_BALANCE`` — балансировка по грунту (катушка над чистым грунтом).
* ``CMD_SET_SENSITIVITY`` — ``param1`` чувствительность 1–10.
"""

SENSOR_COMPONENT_ID = 25  # MAV_COMP_ID_USER1
SAMPLE_NAME = "MD"
STATUS_NAME = "MD_STAT"
SAMPLE_RATE_HZ = 20
NO_TARGET_ID = -1.0

CMD_GROUND_BALANCE = 31010  # MAV_CMD_USER_1
CMD_SET_SENSITIVITY = 31011  # MAV_CMD_USER_2

STATUS_OK = 1
STATUS_BALANCED = 2
STATUS_OVERLOAD = 4
