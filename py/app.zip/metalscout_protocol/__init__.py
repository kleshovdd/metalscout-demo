"""Контракт «на проводе» между программой и устройством.

Этот пакет — единственное, что разделяют программа (`metalscout`), симулятор
(`metalscout_sim`) и будущая прошивка платы датчика (sensor node). Всё описано в терминах
стандартного MAVLink (диалект common + режимы ArduPilot), поэтому настоящий полётный
контроллер и симулятор для программы неотличимы.
"""

from metalscout_protocol.ardupilot import COPTER_MODES, ROVER_MODES, mode_name, mode_number
from metalscout_protocol.detector import (
    CMD_GROUND_BALANCE,
    CMD_SET_SENSITIVITY,
    NO_TARGET_ID,
    SAMPLE_NAME,
    SAMPLE_RATE_HZ,
    SENSOR_COMPONENT_ID,
    STATUS_BALANCED,
    STATUS_NAME,
    STATUS_OK,
    STATUS_OVERLOAD,
)

__all__ = [
    "CMD_GROUND_BALANCE",
    "CMD_SET_SENSITIVITY",
    "COPTER_MODES",
    "NO_TARGET_ID",
    "ROVER_MODES",
    "SAMPLE_NAME",
    "SAMPLE_RATE_HZ",
    "SENSOR_COMPONENT_ID",
    "STATUS_BALANCED",
    "STATUS_NAME",
    "STATUS_OK",
    "STATUS_OVERLOAD",
    "mode_name",
    "mode_number",
]
