"""Геометрия: локальная плоская система координат (метры) вокруг опорной точки.

Для участков до нескольких километров равнопромежуточная проекция даёт ошибку меньше
сантиметра на сотню метров — этого достаточно.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from pydantic import BaseModel, ConfigDict

EARTH_R = 6378137.0


class LatLon(BaseModel):
    model_config = ConfigDict(frozen=True)

    lat: float
    lon: float


@dataclass(frozen=True)
class LocalFrame:
    origin: LatLon

    def to_local(self, lat: float, lon: float) -> tuple[float, float]:
        lat0 = math.radians(self.origin.lat)
        north = math.radians(lat - self.origin.lat) * EARTH_R
        east = math.radians(lon - self.origin.lon) * EARTH_R * math.cos(lat0)
        return east, north

    def to_latlon(self, east: float, north: float) -> LatLon:
        lat0 = math.radians(self.origin.lat)
        lat = self.origin.lat + math.degrees(north / EARTH_R)
        lon = self.origin.lon + math.degrees(east / (EARTH_R * math.cos(lat0)))
        return LatLon(lat=lat, lon=lon)


def distance_m(a: LatLon, b: LatLon) -> float:
    frame = LocalFrame(a)
    e, n = frame.to_local(b.lat, b.lon)
    return math.hypot(e, n)


def polygon_area_m2(points: list[tuple[float, float]]) -> float:
    s = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % len(points)]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def point_in_polygon(x: float, y: float, poly: list[tuple[float, float]]) -> bool:
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside
