"""Язык сообщений программы: английский по умолчанию, русский — по выбору в интерфейсе.

Программа однопользовательская (одно устройство, один интерфейс), поэтому язык общий для
процесса: интерфейс сообщает его через `PUT /api/lang` при подключении и при смене.
Строки пишутся на месте парой tr("English", "Русский").
"""

from __future__ import annotations

from typing import Literal

Lang = Literal["en", "ru"]

_lang: Lang = "en"


def set_lang(lang: Lang) -> None:
    global _lang
    _lang = lang


def get_lang() -> Lang:
    return _lang


def tr(en: str, ru: str) -> str:
    return ru if _lang == "ru" else en
