"""Настройки программы из переменных окружения (у настольного продукта — разумные умолчания)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    web_dist: Path | None
    sim_udp_port: int
    sim_control_port: int
    # Публичный стенд: только демо-режим, без доступа к портам и сети машины.
    demo_only: bool = False

    @property
    def db_path(self) -> Path:
        return self.data_dir / "metalscout.sqlite3"


def load_settings() -> Settings:
    data = os.environ.get("METALSCOUT_DATA_DIR") or str(Path.home() / ".metalscout")
    dist = os.environ.get("METALSCOUT_WEB_DIST")
    return Settings(
        data_dir=Path(data),
        web_dist=Path(dist) if dist else None,
        sim_udp_port=int(os.environ.get("METALSCOUT_SIM_UDP_PORT", "14560")),
        sim_control_port=int(os.environ.get("METALSCOUT_SIM_CONTROL_PORT", "8711")),
        demo_only=os.environ.get("METALSCOUT_DEMO_ONLY", "") in {"1", "true", "yes"},
    )
