"""Маршрут «змейкой» по участку под ширину катушки и оценка времени/батарей."""

from __future__ import annotations

import math
from dataclasses import dataclass

from pydantic import BaseModel

from metalscout.device.profiles import DeviceProfile
from metalscout.geo import LatLon, LocalFrame, polygon_area_m2
from metalscout.i18n import tr

MAX_WAYPOINTS = 650  # запас под лимит миссии ArduPilot на Pixhawk (~720 пунктов)
MIN_SEGMENT_M = 0.3


class PlanError(ValueError):
    """Участок нельзя пройти: слишком мал, слишком велик или вырожден."""


class Lane(BaseModel):
    index: int
    start: LatLon
    end: LatLon
    length_m: float


class RouteEstimate(BaseModel):
    area_m2: float
    lanes: int
    path_m: float
    duration_min: float
    batteries: int
    usable_min_per_battery: float


class Route(BaseModel):
    lanes: list[Lane]
    estimate: RouteEstimate
    lane_spacing_m: float
    heading_deg: float


@dataclass(frozen=True)
class _Seg:
    x1: float
    x2: float
    y: float


def _rotate(x: float, y: float, angle: float) -> tuple[float, float]:
    c, s = math.cos(angle), math.sin(angle)
    return x * c - y * s, x * s + y * c


def _scanline(poly: list[tuple[float, float]], y: float) -> list[tuple[float, float]]:
    xs: list[float] = []
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        if (y1 <= y < y2) or (y2 <= y < y1):
            xs.append(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
    xs.sort()
    return [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]


def plan_route(area: list[LatLon], profile: DeviceProfile, start: LatLon) -> Route:
    if len(area) < 3:
        raise PlanError(tr("The area needs at least three points", "Нужно минимум три точки участка"))
    frame = LocalFrame(start)
    pts = [frame.to_local(p.lat, p.lon) for p in area]
    area_m2 = polygon_area_m2(pts)
    if area_m2 < 4.0:
        raise PlanError(
            tr(
                "The area is too small: at least 2×2 m is needed",
                "Участок слишком маленький: нужно хотя бы 2×2 м",
            )
        )

    # Полосы вдоль самой длинной стороны — меньше разворотов.
    best = max(
        range(len(pts)),
        key=lambda i: math.dist(pts[i], pts[(i + 1) % len(pts)]),
    )
    (ax, ay), (bx, by) = pts[best], pts[(best + 1) % len(pts)]
    angle = math.atan2(by - ay, bx - ax)
    rot = [_rotate(x, y, -angle) for x, y in pts]
    ys = [p[1] for p in rot]
    spacing = profile.lane_spacing_m
    segs: list[_Seg] = []
    y = min(ys) + spacing / 2
    while y < max(ys):
        for x1, x2 in _scanline(rot, y):
            if x2 - x1 >= MIN_SEGMENT_M:
                segs.append(_Seg(x1, x2, y))
        y += spacing
    if not segs:
        raise PlanError(
            tr(
                "The area is narrower than the coil — draw it wider",
                "Участок уже ширины катушки — нарисуйте его шире",
            )
        )
    if len(segs) * 2 > MAX_WAYPOINTS:
        raise PlanError(
            tr(
                f"The area is too large for one route ({len(segs)} lanes). Split it into several parts.",
                f"Участок слишком большой для одного маршрута ({len(segs)} полос). "
                "Разделите его на несколько частей.",
            )
        )

    hx, hy = _rotate(0.0, 0.0, -angle)  # точка старта в повёрнутой системе

    def ordered(reverse_lanes: bool, flip_first: bool) -> list[tuple[float, float, float, float]]:
        seq = list(reversed(segs)) if reverse_lanes else list(segs)
        out = []
        for i, s in enumerate(seq):
            forward = (i % 2 == 0) != flip_first
            out.append((s.x1, s.y, s.x2, s.y) if forward else (s.x2, s.y, s.x1, s.y))
        return out

    variants = [ordered(r, f) for r in (False, True) for f in (False, True)]
    chosen = min(variants, key=lambda v: math.dist((hx, hy), (v[0][0], v[0][1])))

    lanes: list[Lane] = []
    path = 0.0
    prev: tuple[float, float] | None = None
    for i, (x1, y1, x2, y2) in enumerate(chosen):
        s_e, s_n = _rotate(x1, y1, angle)
        e_e, e_n = _rotate(x2, y2, angle)
        length = math.dist((x1, y1), (x2, y2))
        if prev is not None:
            path += math.dist(prev, (s_e, s_n))
        path += length
        prev = (e_e, e_n)
        lanes.append(
            Lane(
                index=i,
                start=frame.to_latlon(s_e, s_n),
                end=frame.to_latlon(e_e, e_n),
                length_m=round(length, 2),
            )
        )

    first = frame.to_local(lanes[0].start.lat, lanes[0].start.lon)
    last = frame.to_local(lanes[-1].end.lat, lanes[-1].end.lon)
    transit = math.hypot(*first) + math.hypot(*last)
    seconds = (
        path / profile.search_speed_mps
        + len(lanes) * profile.turn_time_s
        + transit / profile.transit_speed_mps
        + profile.takeoff_time_s * 2
    )
    usable = profile.endurance_min * (1 - profile.battery_reserve_pct / 100)
    minutes = seconds / 60
    return Route(
        lanes=lanes,
        lane_spacing_m=spacing,
        heading_deg=round((90 - math.degrees(angle)) % 360, 1),
        estimate=RouteEstimate(
            area_m2=round(area_m2, 1),
            lanes=len(lanes),
            path_m=round(path, 1),
            duration_min=round(minutes, 1),
            batteries=max(1, math.ceil(minutes / usable)),
            usable_min_per_battery=round(usable, 1),
        ),
    )
