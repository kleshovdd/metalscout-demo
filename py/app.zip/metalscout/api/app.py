"""HTTP API и WebSocket программы MetalScout.

Сервер слушает только 127.0.0.1: интерфейс и программа работают на одном компьютере.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Annotated, Any, Literal

from fastapi import Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from metalscout.api.events import EventBus
from metalscout.config import Settings, load_settings
from metalscout.device.ardupilot import ArduPilotDevice, DeviceError, Telemetry
from metalscout.device.link import list_serial_ports
from metalscout.device.profiles import PROFILES, DeviceKind, DeviceProfile
from metalscout.geo import LatLon
from metalscout.i18n import Lang, set_lang, tr
from metalscout.planning.route import PlanError, Route, plan_route
from metalscout.session import export
from metalscout.session.controller import SessionController, SessionError
from metalscout.session.models import Find, FindStatus, Preflight, Session
from metalscout.session.repo import Repository
from metalscout.simlaunch import SimulatorProcess
from metalscout.storage.db import Database

log = logging.getLogger(__name__)


@dataclass
class Services:
    settings: Settings
    bus: EventBus
    db: Database
    repo: Repository
    device: ArduPilotDevice
    sessions: SessionController
    sim: SimulatorProcess


# ---------- схемы запросов/ответов ----------
class DeviceInfo(BaseModel):
    telemetry: Telemetry
    profile: DeviceProfile | None
    simulator: bool
    # Публичный стенд: подключить можно только демо-устройство.
    demo_only: bool = False


class ConnectRequest(BaseModel):
    mode: Literal["simulator", "serial", "udp"]
    vehicle: DeviceKind = DeviceKind.DRONE
    port: str | None = None
    baud: int = 57600
    udp_port: int = 14550
    speedup: float = Field(5.0, ge=0.5, le=20)


class AreaRequest(BaseModel):
    area: list[LatLon] = Field(min_length=3, max_length=200)
    name: str | None = Field(None, max_length=80)


class PlanResponse(BaseModel):
    route: Route
    profile: DeviceProfile


class EmergencyRequest(BaseModel):
    action: Literal["hold", "return", "land"]


class FindPatch(BaseModel):
    status: FindStatus | None = None
    note: str | None = Field(None, max_length=500)


class LangRequest(BaseModel):
    lang: Lang


class SimAction(BaseModel):
    action: Literal["swap_battery", "speedup", "link_down", "gps"]
    value: float | None = None
    seconds: float | None = None
    quality: Literal["rtk_fixed", "rtk_float", "3d", "none"] | None = None


def services(request: Request) -> Services:
    svc: Services = request.app.state.services
    return svc


Svc = Annotated[Services, Depends(services)]


def _user_error(exc: Exception) -> HTTPException:
    return HTTPException(status_code=409, detail=str(exc))


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        loop = asyncio.get_running_loop()
        bus = EventBus()
        db = Database(settings.db_path)
        repo = Repository(db)

        def emit_device(kind: str, payload: dict[str, Any]) -> None:
            # Интерфейс ждёт в событии «device» полный DeviceInfo (с профилем и флагом демо),
            # а устройство знает только свою телеметрию — дополняем здесь.
            svc_now: Services | None = getattr(app.state, "services", None)
            if kind == "device" and svc_now is not None:
                payload = _device_info(svc_now).model_dump(mode="json")
            bus.publish(kind, payload)

        device = ArduPilotDevice(loop, emit_device)
        controller = SessionController(device, repo, bus.publish)
        controller.restore()
        controller.start_background()
        svc = Services(
            settings,
            bus,
            db,
            repo,
            device,
            controller,
            SimulatorProcess(settings.sim_udp_port, settings.sim_control_port),
        )
        app.state.services = svc
        telemetry_task = asyncio.create_task(_telemetry_loop(svc))
        idle_task = asyncio.create_task(_demo_idle_loop(svc)) if settings.demo_only else None
        try:
            yield
        finally:
            telemetry_task.cancel()
            if idle_task is not None:
                idle_task.cancel()
            await controller.stop_background()
            await device.disconnect()
            svc.sim.stop()
            db.close()

    app = FastAPI(title="MetalScout", version="0.1.0", lifespan=lifespan)

    # ---------- язык сообщений ----------
    @app.put("/api/lang")
    async def put_lang(req: LangRequest) -> dict[str, str]:
        set_lang(req.lang)
        return {"lang": req.lang}

    # ---------- устройство ----------
    @app.get("/api/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/device")
    async def get_device(svc: Svc) -> DeviceInfo:
        return _device_info(svc)

    @app.get("/api/device/ports")
    async def ports(svc: Svc) -> list[dict[str, str]]:
        if svc.settings.demo_only:
            return []
        try:
            return await asyncio.to_thread(list_serial_ports)
        except Exception:
            log.warning("Не удалось получить список портов", exc_info=True)
            return []

    @app.post("/api/device/connect")
    async def connect(req: ConnectRequest, svc: Svc) -> DeviceInfo:
        if svc.settings.demo_only and req.mode != "simulator":
            raise HTTPException(
                403,
                tr(
                    "This is a public demo: only “Demo” mode is available",
                    "Это публичное демо: доступен только режим «Демо»",
                ),
            )
        if req.mode == "simulator":
            svc.sim.start(req.vehicle, req.speedup)
            url, baud = svc.sim.url, 57600
        elif req.mode == "serial":
            if not req.port:
                raise HTTPException(422, tr("Choose a port", "Выберите порт"))
            svc.sim.stop()
            url, baud = req.port, req.baud
        else:
            svc.sim.stop()
            url, baud = f"udpin:0.0.0.0:{req.udp_port}", 57600
        try:
            await svc.device.connect(url, baud, timeout_s=15 if req.mode == "simulator" else 10)
        except DeviceError as exc:
            svc.sim.stop()
            raise _user_error(exc) from exc
        return _device_info(svc)

    @app.post("/api/device/disconnect")
    async def disconnect(svc: Svc) -> DeviceInfo:
        await svc.device.disconnect()
        svc.sim.stop()
        return _device_info(svc)

    @app.post("/api/device/ground-balance")
    async def ground_balance(svc: Svc) -> DeviceInfo:
        try:
            await svc.device.ground_balance()
        except DeviceError as exc:
            raise _user_error(exc) from exc
        return _device_info(svc)

    @app.post("/api/device/emergency")
    async def emergency(req: EmergencyRequest, svc: Svc) -> DeviceInfo:
        """Аварийные команды идут прямо в автопилот, в обход сценария поиска."""
        try:
            if req.action == "hold":
                await svc.device.hold()
            elif req.action == "return":
                await svc.device.return_home()
            else:
                await svc.device.land_or_stop()
        except DeviceError as exc:
            raise _user_error(exc) from exc
        svc.sessions.on_emergency()
        return _device_info(svc)

    # ---------- планирование и поиск ----------
    @app.post("/api/plan")
    async def plan(req: AreaRequest, svc: Svc) -> PlanResponse:
        profile, start = _profile_and_start(svc, req.area)
        try:
            route = plan_route(req.area, profile, start)
        except PlanError as exc:
            raise HTTPException(422, str(exc)) from exc
        return PlanResponse(route=route, profile=profile)

    @app.get("/api/sessions")
    async def list_sessions(svc: Svc) -> list[Session]:
        return svc.repo.list_sessions()

    @app.post("/api/sessions")
    async def create_session(req: AreaRequest, svc: Svc) -> Session:
        current = svc.sessions.session
        if current is not None and current.state not in ("planned", "completed", "cancelled"):
            raise HTTPException(409, tr("Finish the current search first", "Сначала завершите текущий поиск"))
        profile, start = _profile_and_start(svc, req.area)
        try:
            route = plan_route(req.area, profile, start)
        except PlanError as exc:
            raise HTTPException(422, str(exc)) from exc
        count = len(svc.repo.list_sessions()) + 1
        name = req.name or tr(f"Search #{count}", f"Поиск №{count}")
        created = svc.repo.create_session(name, profile.kind, req.area, route)
        return svc.sessions.activate(created.id)

    @app.get("/api/sessions/current")
    async def current_session(svc: Svc) -> Session | None:
        return svc.sessions.session

    @app.post("/api/sessions/close")
    async def close_session(svc: Svc) -> dict[str, bool]:
        """«Новый поиск»: убрать завершённый поиск с экрана (он остаётся в истории)."""
        cur = svc.sessions.session
        if cur is not None and cur.state not in ("planned", "completed", "cancelled"):
            raise HTTPException(409, tr("Finish the current search first", "Сначала завершите текущий поиск"))
        svc.sessions.session = None
        svc.sessions.processor = None
        return {"ok": True}

    @app.get("/api/sessions/{sid}")
    async def get_session(sid: int, svc: Svc) -> Session:
        s = svc.repo.get_session(sid)
        if s is None:
            raise HTTPException(404, tr("Search not found", "Поиск не найден"))
        return s

    @app.delete("/api/sessions/{sid}")
    async def delete_session(sid: int, svc: Svc) -> dict[str, bool]:
        cur = svc.sessions.session
        if cur is not None and cur.id == sid and cur.state not in ("planned", "completed", "cancelled"):
            raise HTTPException(409, tr("Cannot delete a running search", "Нельзя удалить идущий поиск"))
        svc.repo.delete_session(sid)
        if cur is not None and cur.id == sid:
            svc.sessions.session = None
            svc.sessions.processor = None
        return {"ok": True}

    @app.post("/api/sessions/{sid}/open")
    async def open_session(sid: int, svc: Svc) -> Session:
        cur = svc.sessions.session
        if (
            cur is not None
            and cur.id != sid
            and cur.state not in ("planned", "completed", "cancelled", "waiting")
        ):
            raise HTTPException(409, tr("Finish the current search first", "Сначала завершите текущий поиск"))
        try:
            return svc.sessions.activate(sid)
        except SessionError as exc:
            raise _user_error(exc) from exc

    @app.get("/api/sessions/{sid}/preflight")
    async def preflight(sid: int, svc: Svc) -> Preflight:
        _ensure_current(svc, sid)
        return svc.sessions.preflight()

    @app.post("/api/sessions/{sid}/{action}")
    async def session_action(
        sid: int, action: Literal["start", "pause", "resume", "return", "finish"], svc: Svc
    ) -> Session:
        _ensure_current(svc, sid)
        c = svc.sessions
        try:
            if action == "start":
                return await c.start()
            if action == "pause":
                return await c.pause()
            if action == "resume":
                return await c.resume()
            if action == "return":
                return await c.return_home()
            return await c.finish()
        except (SessionError, DeviceError) as exc:
            raise _user_error(exc) from exc

    @app.get("/api/sessions/{sid}/finds")
    async def finds(sid: int, svc: Svc) -> list[Find]:
        return svc.repo.list_finds(sid)

    @app.get("/api/sessions/{sid}/samples")
    async def samples(sid: int, svc: Svc) -> dict[str, Any]:
        rows = svc.repo.samples(sid)
        return {
            "items": [
                [
                    round(r["lat"], 7),
                    round(r["lon"], 7),
                    round(r["excess"], 3),
                    int(r["target_id"]),
                    r["valid"],
                ]
                for r in rows
            ]
        }

    @app.patch("/api/finds/{find_id}")
    async def patch_find(find_id: int, req: FindPatch, svc: Svc) -> Find:
        f = svc.repo.update_find(find_id, req.status, req.note)
        if f is None:
            raise HTTPException(404, tr("Find not found", "Находка не найдена"))
        svc.bus.publish("find", f.model_dump(mode="json"))
        return f

    @app.get("/api/sessions/{sid}/export.{fmt}")
    async def export_finds(
        sid: int, fmt: Literal["xlsx", "gpx", "kml", "geojson", "csv"], svc: Svc
    ) -> Response:
        s = svc.repo.get_session(sid)
        if s is None:
            raise HTTPException(404, tr("Search not found", "Поиск не найден"))
        items = svc.repo.list_finds(sid)
        if fmt == "xlsx":
            return Response(
                export.to_xlsx(s, items),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f'attachment; filename="metalscout-{sid}.xlsx"'},
            )
        body = {
            "gpx": lambda: export.to_gpx(s, items),
            "kml": lambda: export.to_kml(s, items),
            "geojson": lambda: export.to_geojson(s, items),
            "csv": lambda: export.to_csv(items),
        }[fmt]()
        media = {
            "gpx": "application/gpx+xml",
            "kml": "application/vnd.google-earth.kml+xml",
            "geojson": "application/geo+json",
            "csv": "text/csv",
        }[fmt]
        filename = f"metalscout-{sid}.{fmt}"
        return PlainTextResponse(
            body,
            media_type=f"{media}; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # ---------- демо: пульт симулятора ----------
    @app.get("/api/sim")
    async def sim_state(svc: Svc) -> dict[str, Any]:
        if not svc.sim.running:
            return {"running": False}
        try:
            state = await svc.sim.call("GET", "state")
        except OSError:
            return {"running": True}
        return {"running": True, **state}

    @app.get("/api/sim/truth")
    async def sim_truth(svc: Svc) -> list[dict[str, Any]]:
        if not svc.sim.running:
            raise HTTPException(409, tr("Simulator is not running", "Симулятор не запущен"))
        result: list[dict[str, Any]] = await svc.sim.call("GET", "truth")
        return result

    @app.post("/api/sim")
    async def sim_action(req: SimAction, svc: Svc) -> dict[str, Any]:
        if not svc.sim.running:
            raise HTTPException(409, tr("Simulator is not running", "Симулятор не запущен"))
        body = req.model_dump(exclude_none=True, exclude={"action"})
        await svc.sim.call("POST", req.action, body)
        return {"ok": True}

    # ---------- живые события ----------
    @app.websocket("/api/ws")
    async def ws(socket: WebSocket) -> None:
        svc: Services = socket.app.state.services
        await socket.accept()
        q = svc.bus.subscribe()
        try:
            await socket.send_json({"type": "device", "data": _device_info(svc).model_dump(mode="json")})
            if svc.sessions.session is not None:
                await socket.send_json(
                    {"type": "session", "data": svc.sessions.session.model_dump(mode="json")}
                )
            while True:
                event = await q.get()
                await socket.send_json(event)
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            svc.bus.unsubscribe(q)

    # ---------- собранный интерфейс ----------
    if settings.web_dist is not None and settings.web_dist.is_dir():
        dist = settings.web_dist
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        async def spa(path: str) -> FileResponse:
            candidate = dist / path
            if path and candidate.is_file() and dist in candidate.resolve().parents:
                return FileResponse(candidate)
            return FileResponse(dist / "index.html")

    return app


DEMO_IDLE_S = 10 * 60


async def _demo_idle_loop(svc: Services) -> None:
    """Публичный стенд: никто не смотрит 10 минут — выключить симулятор, не тратить процессор."""
    loop = asyncio.get_running_loop()
    last_seen = loop.time()
    while True:
        await asyncio.sleep(30)
        now = loop.time()
        if svc.bus.subscribers > 0:
            last_seen = now
        elif svc.sim.running and now - last_seen > DEMO_IDLE_S:
            log.info("Демо: нет зрителей %d мин — выключаю симулятор", DEMO_IDLE_S // 60)
            with contextlib.suppress(Exception):
                await svc.device.disconnect()
            svc.sim.stop()


def _device_info(svc: Services) -> DeviceInfo:
    t = svc.device.t
    return DeviceInfo(
        telemetry=t,
        profile=PROFILES[t.kind] if t.kind is not None else None,
        simulator=svc.sim.running,
        demo_only=svc.settings.demo_only,
    )


def _profile_and_start(svc: Services, area: list[LatLon]) -> tuple[DeviceProfile, LatLon]:
    t = svc.device.t
    if t.kind is None or t.lat is None or t.lon is None:
        raise HTTPException(
            409,
            tr(
                "Connect the device first: the route is planned for it",
                "Сначала подключите устройство: маршрут строится под него",
            ),
        )
    start = t.home or LatLon(lat=t.lat, lon=t.lon)
    return PROFILES[t.kind], start


def _ensure_current(svc: Services, sid: int) -> None:
    cur = svc.sessions.session
    if cur is None or cur.id != sid:
        raise HTTPException(409, tr("This search is not open", "Этот поиск не открыт"))


async def _telemetry_loop(svc: Services) -> None:
    """Телеметрия в интерфейс 5 раз в секунду (чаще человеку не нужно)."""
    while True:
        await asyncio.sleep(0.2)
        with contextlib.suppress(Exception):
            if svc.device.t.connected:
                svc.bus.publish("telemetry", svc.device.t.model_dump(mode="json"))
