"""Хранилище: один файл SQLite в папке данных пользователя.

Для настольного продукта на одного пользователя SQLite надёжнее и проще сервера БД: ничего
не нужно устанавливать, файл легко скопировать. Схема меняется пронумерованными миграциями.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from collections.abc import Iterable, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

MIGRATIONS: tuple[str, ...] = (
    """
    CREATE TABLE sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        device_kind TEXT NOT NULL,
        area_json TEXT NOT NULL,
        route_json TEXT NOT NULL,
        state TEXT NOT NULL,
        state_reason TEXT,
        next_lane INTEGER NOT NULL DEFAULT 0,
        lanes_total INTEGER NOT NULL,
        coverage_pct REAL NOT NULL DEFAULT 0,
        batteries_used INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
    );
    CREATE TABLE finds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        number INTEGER NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        strength INTEGER NOT NULL,
        target_id INTEGER,
        category TEXT NOT NULL,
        depth_cm INTEGER,
        passes INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'new',
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (session_id, number)
    );
    CREATE TABLE samples (
        session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        t_ms INTEGER NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        signal REAL NOT NULL,
        excess REAL NOT NULL,
        target_id REAL NOT NULL,
        coil_h REAL,
        valid INTEGER NOT NULL
    );
    CREATE INDEX samples_session ON samples(session_id);
    """,
)


def now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        self._migrate()

    def _migrate(self) -> None:
        with self._lock:
            version = int(self._conn.execute("PRAGMA user_version").fetchone()[0])
            for i, sql in enumerate(MIGRATIONS[version:], start=version + 1):
                self._conn.executescript(f"BEGIN; {sql}; PRAGMA user_version = {i}; COMMIT;")

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self._lock:
            cur = self._conn.execute(sql, params)
            return int(cur.lastrowid or 0)

    def executemany(self, sql: str, rows: Iterable[Sequence[Any]]) -> None:
        with self._lock:
            self._conn.execute("BEGIN")
            self._conn.executemany(sql, rows)
            self._conn.execute("COMMIT")

    def one(self, sql: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(sql, params).fetchone()
        return dict(row) if row is not None else None

    def all(self, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]


def dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
