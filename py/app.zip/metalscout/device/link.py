"""Канал MAVLink: открытие порта, поток чтения, отправка, heartbeat наземной станции.

pymavlink блокирующий, поэтому чтение идёт в отдельном потоке, а сообщения передаются в
asyncio через `loop.call_soon_threadsafe`. Отправка защищена замком.
"""

from __future__ import annotations

import asyncio
import logging
import os
import threading
import time
from collections.abc import Callable
from typing import Any

os.environ.setdefault("MAVLINK20", "1")

from pymavlink import mavutil

from metalscout.i18n import tr

log = logging.getLogger(__name__)

GCS_SYSID = 255
GCS_COMPID = 190  # MAV_COMP_ID_MISSIONPLANNER

MessageHandler = Callable[[Any], None]


class LinkError(RuntimeError):
    pass


class MavlinkLink:
    def __init__(
        self, url: str, baud: int, loop: asyncio.AbstractEventLoop, on_message: MessageHandler
    ) -> None:
        self.url = url
        self.baud = baud
        self._loop = loop
        self._on_message = on_message
        self._conn: Any = None
        self._send_lock = threading.Lock()
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self.last_rx = 0.0

    @property
    def mav(self) -> Any:
        return self._conn.mav

    def open(self) -> None:
        try:
            self._conn = mavutil.mavlink_connection(
                self.url,
                baud=self.baud,
                source_system=GCS_SYSID,
                source_component=GCS_COMPID,
                autoreconnect=True,
            )
        except Exception as exc:  # pymavlink бросает что угодно: OSError, SerialException…
            raise LinkError(
                tr(f"Could not open {self.url}: {exc}", f"Не удалось открыть {self.url}: {exc}")
            ) from exc
        self._stop.clear()
        for target, name in ((self._reader, "mav-reader"), (self._heartbeat, "mav-heartbeat")):
            t = threading.Thread(target=target, name=name, daemon=True)
            t.start()
            self._threads.append(t)

    def close(self) -> None:
        self._stop.set()
        for t in self._threads:
            t.join(timeout=2)
        self._threads.clear()
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:  # закрытие порта не должно ронять программу
                log.debug("close failed", exc_info=True)
            self._conn = None

    def send(self, fn: Callable[[Any], None]) -> None:
        """Отправить сообщение: fn получает объект MAVLink (`mav.xxx_send(...)`)."""
        if self._conn is None:
            raise LinkError(tr("No connection", "Нет соединения"))
        with self._send_lock:
            fn(self._conn.mav)

    def _reader(self) -> None:
        while not self._stop.is_set():
            try:
                msg = self._conn.recv_match(blocking=True, timeout=0.2)
            except Exception:
                log.warning("Ошибка чтения MAVLink", exc_info=True)
                time.sleep(0.2)
                continue
            if msg is None or msg.get_type() == "BAD_DATA":
                continue
            self.last_rx = time.monotonic()
            self._loop.call_soon_threadsafe(self._on_message, msg)

    def _heartbeat(self) -> None:
        ml = mavutil.mavlink
        while not self._stop.wait(1.0):
            try:
                self.send(
                    lambda m: m.heartbeat_send(
                        ml.MAV_TYPE_GCS, ml.MAV_AUTOPILOT_INVALID, 0, 0, ml.MAV_STATE_ACTIVE
                    )
                )
            except Exception:
                log.debug("heartbeat failed", exc_info=True)


def list_serial_ports() -> list[dict[str, str]]:
    """Порты, к которым можно подключить радиомодем или кабель."""
    ports = []
    for p in mavutil.auto_detect_serial(preferred_list=["*"]):
        ports.append({"device": str(p.device), "description": str(getattr(p, "description", "") or "")})
    return ports
