"""Профили устройств: всё, чем дрон отличается от машинки, — здесь, а не в ветках кода.

Значения по умолчанию подобраны под комплект «аппарат + металлоискатель 26 см (дрон) /
40 см (машинка)». Для настоящего устройства их правят в профиле, а не в коде.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class DeviceKind(StrEnum):
    DRONE = "drone"
    ROVER = "rover"


class DeviceProfile(BaseModel):
    kind: DeviceKind
    title: str
    autopilot_family: str = Field(description="copter | rover — таблица режимов ArduPilot")
    coil_width_m: float = Field(description="Ширина полосы, которую «видит» катушка")
    lane_overlap: float = Field(0.25, ge=0, lt=0.9, description="Перекрытие соседних полос")
    search_speed_mps: float = Field(description="Скорость на полосе")
    transit_speed_mps: float
    search_alt_m: float = Field(0.0, description="Дрон: высота рамы над грунтом во время поиска")
    coil_target_height_m: float = Field(description="Желаемая высота катушки над грунтом")
    coil_max_height_m: float = Field(description="Выше — измерение не считается покрытием")
    coil_forward_m: float = Field(0.0, description="Вынос катушки вперёд от GPS-антенны")
    endurance_min: float = Field(description="Работа на одной батарее при поиске, мин")
    battery_reserve_pct: float = Field(25.0, description="Запас батареи на возврат и посадку")
    turn_time_s: float = Field(description="Время на разворот в конце полосы")
    takeoff_time_s: float = 0.0

    @property
    def lane_spacing_m(self) -> float:
        return self.coil_width_m * (1.0 - self.lane_overlap)


DRONE = DeviceProfile(
    kind=DeviceKind.DRONE,
    title="Drone with metal detector",
    autopilot_family="copter",
    coil_width_m=0.26,
    lane_overlap=0.25,
    search_speed_mps=1.0,
    transit_speed_mps=3.0,
    search_alt_m=1.7,
    coil_target_height_m=0.3,
    coil_max_height_m=0.55,
    endurance_min=24.0,
    battery_reserve_pct=25.0,
    turn_time_s=2.5,
    takeoff_time_s=10.0,
)

ROVER = DeviceProfile(
    kind=DeviceKind.ROVER,
    title="Ground robot with metal detector",
    autopilot_family="rover",
    coil_width_m=0.4,
    lane_overlap=0.25,
    search_speed_mps=1.0,
    transit_speed_mps=1.5,
    coil_target_height_m=0.06,
    coil_max_height_m=0.25,
    coil_forward_m=1.1,
    endurance_min=180.0,
    battery_reserve_pct=15.0,
    turn_time_s=5.0,
)

PROFILES: dict[DeviceKind, DeviceProfile] = {DeviceKind.DRONE: DRONE, DeviceKind.ROVER: ROVER}
