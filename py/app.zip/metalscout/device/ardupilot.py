"""Устройство на ArduPilot (Copter или Rover) с платой металлоискателя.

Высокоуровневые асинхронные операции поверх MAVLink: подключение и определение типа,
телеметрия, команды с подтверждением, загрузка миссии, команды датчику.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel
from pymavlink import mavutil

from metalscout.device.link import LinkError, MavlinkLink
from metalscout.device.profiles import DeviceKind
from metalscout.geo import LatLon
from metalscout.i18n import tr
from metalscout_protocol import (
    CMD_GROUND_BALANCE,
    CMD_SET_SENSITIVITY,
    SAMPLE_NAME,
    SENSOR_COMPONENT_ID,
    STATUS_BALANCED,
    STATUS_NAME,
    STATUS_OK,
    mode_name,
    mode_number,
)

log = logging.getLogger(__name__)
ml = mavutil.mavlink

COPTER_TYPES = {
    ml.MAV_TYPE_QUADROTOR,
    ml.MAV_TYPE_HEXAROTOR,
    ml.MAV_TYPE_OCTOROTOR,
    ml.MAV_TYPE_TRICOPTER,
    ml.MAV_TYPE_COAXIAL,
}
ROVER_TYPES = {ml.MAV_TYPE_GROUND_ROVER}

# Сообщение → желаемый интервал, с. Запрашиваем явно: у настоящего ArduPilot по умолчанию
# частоты зависят от параметров SRx_*, а нам нужны конкретные.
STREAMS: dict[int, float] = {
    ml.MAVLINK_MSG_ID_GLOBAL_POSITION_INT: 0.1,
    ml.MAVLINK_MSG_ID_ATTITUDE: 0.1,
    ml.MAVLINK_MSG_ID_GPS_RAW_INT: 0.5,
    ml.MAVLINK_MSG_ID_SYS_STATUS: 1.0,
    ml.MAVLINK_MSG_ID_BATTERY_STATUS: 1.0,
    ml.MAVLINK_MSG_ID_DISTANCE_SENSOR: 0.1,
    ml.MAVLINK_MSG_ID_MISSION_CURRENT: 1.0,
    ml.MAVLINK_MSG_ID_SYSTEM_TIME: 1.0,
}

LINK_TIMEOUT_S = 3.0


class DeviceError(RuntimeError):
    """Ошибка, понятная пользователю (текст показывается в интерфейсе)."""


class Telemetry(BaseModel):
    connected: bool = False
    link_ok: bool = False
    url: str | None = None
    kind: DeviceKind | None = None
    firmware: str | None = None
    armed: bool = False
    mode: str | None = None
    lat: float | None = None
    lon: float | None = None
    alt_m: float | None = None
    heading_deg: float | None = None
    speed_mps: float | None = None
    gps_fix: int = 0
    gps_sats: int = 0
    battery_pct: float | None = None
    battery_v: float | None = None
    coil_height_m: float | None = None
    mission_seq: int = 0
    home: LatLon | None = None
    sensor_online: bool = False
    sensor_balanced: bool = False
    time_boot_ms: int = 0


@dataclass(frozen=True)
class MissionItemSpec:
    command: int
    frame: int = ml.MAV_FRAME_GLOBAL_RELATIVE_ALT_INT
    lat: float = 0.0
    lon: float = 0.0
    alt: float = 0.0
    param1: float = 0.0
    param2: float = 0.0
    param3: float = 0.0
    param4: float = 0.0


EventSink = Callable[[str, dict[str, Any]], None]
MessageListener = Callable[[Any], None]


class ArduPilotDevice:
    def __init__(self, loop: asyncio.AbstractEventLoop, emit: EventSink) -> None:
        self._loop = loop
        self._emit = emit
        self.link: MavlinkLink | None = None
        self.t = Telemetry()
        self.sysid = 1
        self._listeners: list[MessageListener] = []
        self._acks: dict[tuple[int, int], asyncio.Future[int]] = {}
        self._mission_requests: asyncio.Queue[Any] = asyncio.Queue()
        self._heartbeat_seen = asyncio.Event()
        self._last_vehicle_hb = 0.0
        self._last_sensor_hb = 0.0
        self._watchdog: asyncio.Task[None] | None = None

    # ---------- подключение ----------
    @property
    def family(self) -> Literal["copter", "rover"]:
        return "rover" if self.t.kind == DeviceKind.ROVER else "copter"

    async def connect(self, url: str, baud: int = 57600, timeout_s: float = 10.0) -> Telemetry:
        if self.link is not None:
            await self.disconnect()
        self._heartbeat_seen.clear()
        self.t = Telemetry(url=url)
        link = MavlinkLink(url, baud, self._loop, self._on_message)
        try:
            await asyncio.to_thread(link.open)
        except LinkError as exc:
            raise DeviceError(str(exc)) from exc
        self.link = link
        try:
            await asyncio.wait_for(self._heartbeat_seen.wait(), timeout_s)
        except TimeoutError as exc:
            await self.disconnect()
            raise DeviceError(
                tr(
                    "The device is not responding. "
                    "Check that it is powered on and the right port is selected.",
                    "Устройство не отвечает. Проверьте, что оно включено, и правильно выбран порт.",
                )
            ) from exc
        self.t.connected = True
        self.t.link_ok = True
        for msg_id, interval in STREAMS.items():
            await self._command_nowait(ml.MAV_CMD_SET_MESSAGE_INTERVAL, msg_id, interval * 1e6)
        await self._command_nowait(ml.MAV_CMD_REQUEST_MESSAGE, ml.MAVLINK_MSG_ID_AUTOPILOT_VERSION)
        await self._command_nowait(ml.MAV_CMD_REQUEST_MESSAGE, ml.MAVLINK_MSG_ID_HOME_POSITION)
        self._watchdog = asyncio.create_task(self._watch_link())
        self._emit("device", self.t.model_dump(mode="json"))
        return self.t

    async def disconnect(self) -> None:
        if self._watchdog is not None:
            self._watchdog.cancel()
            self._watchdog = None
        if self.link is not None:
            link = self.link
            self.link = None
            await asyncio.to_thread(link.close)
        self.t = Telemetry()
        self._emit("device", self.t.model_dump(mode="json"))

    def add_listener(self, fn: MessageListener) -> None:
        self._listeners.append(fn)

    def remove_listener(self, fn: MessageListener) -> None:
        if fn in self._listeners:
            self._listeners.remove(fn)

    async def _watch_link(self) -> None:
        was_ok = True
        while True:
            await asyncio.sleep(0.5)
            now = time.monotonic()
            ok = now - self._last_vehicle_hb < LINK_TIMEOUT_S
            self.t.link_ok = ok
            self.t.sensor_online = now - self._last_sensor_hb < LINK_TIMEOUT_S
            if ok != was_ok:
                self._emit("link", {"ok": ok})
                was_ok = ok

    # ---------- приём ----------
    def _on_message(self, msg: Any) -> None:
        kind = msg.get_type()
        src_comp = msg.get_srcComponent()
        if kind == "HEARTBEAT":
            self._on_heartbeat(msg, src_comp)
        elif kind == "COMMAND_ACK":
            fut = self._acks.pop((src_comp, int(msg.command)), None)
            if fut is not None and not fut.done():
                fut.set_result(int(msg.result))
        elif kind in ("MISSION_REQUEST_INT", "MISSION_REQUEST", "MISSION_ACK"):
            self._mission_requests.put_nowait(msg)
        else:
            self._update_telemetry(kind, msg)
        for fn in list(self._listeners):
            try:
                fn(msg)
            except Exception:
                log.exception("Ошибка обработчика сообщения %s", kind)

    def _on_heartbeat(self, msg: Any, src_comp: int) -> None:
        now = time.monotonic()
        if src_comp == SENSOR_COMPONENT_ID:
            self._last_sensor_hb = now
            self.t.sensor_online = True
            return
        if msg.autopilot == ml.MAV_AUTOPILOT_INVALID:
            return
        if msg.type in COPTER_TYPES:
            kind = DeviceKind.DRONE
        elif msg.type in ROVER_TYPES:
            kind = DeviceKind.ROVER
        else:
            return
        self.sysid = msg.get_srcSystem()
        self._last_vehicle_hb = now
        self.t.kind = kind
        armed = bool(msg.base_mode & ml.MAV_MODE_FLAG_SAFETY_ARMED)
        mode = mode_name(self.family, int(msg.custom_mode))
        if armed != self.t.armed or mode != self.t.mode:
            self.t.armed = armed
            self.t.mode = mode
            self._emit("mode", {"mode": mode, "armed": armed})
        self._heartbeat_seen.set()

    def _update_telemetry(self, kind: str, msg: Any) -> None:
        t = self.t
        if kind == "GLOBAL_POSITION_INT":
            t.lat = msg.lat / 1e7
            t.lon = msg.lon / 1e7
            t.alt_m = msg.relative_alt / 1000
            t.heading_deg = msg.hdg / 100 if msg.hdg != 65535 else None
            t.speed_mps = ((msg.vx / 100) ** 2 + (msg.vy / 100) ** 2) ** 0.5
            t.time_boot_ms = int(msg.time_boot_ms)
        elif kind == "GPS_RAW_INT":
            t.gps_fix = int(msg.fix_type)
            t.gps_sats = int(msg.satellites_visible)
        elif kind == "SYS_STATUS":
            if msg.battery_remaining >= 0:
                t.battery_pct = float(msg.battery_remaining)
            t.battery_v = msg.voltage_battery / 1000
        elif kind == "DISTANCE_SENSOR":
            t.coil_height_m = msg.current_distance / 100
        elif kind == "MISSION_CURRENT":
            t.mission_seq = int(msg.seq)
        elif kind == "HOME_POSITION":
            t.home = LatLon(lat=msg.latitude / 1e7, lon=msg.longitude / 1e7)
        elif kind == "AUTOPILOT_VERSION":
            v = int(msg.flight_sw_version)
            name = "ArduCopter" if self.family == "copter" else "ArduRover"
            t.firmware = f"{name} {v >> 24 & 0xFF}.{v >> 16 & 0xFF}.{v >> 8 & 0xFF}"
        elif kind == "NAMED_VALUE_INT" and msg.name == STATUS_NAME:
            t.sensor_balanced = bool(msg.value & STATUS_BALANCED)
            t.sensor_online = bool(msg.value & STATUS_OK)
        elif kind == "STATUSTEXT":
            text = msg.text if isinstance(msg.text, str) else msg.text.decode(errors="replace")
            self._emit("autopilot_text", {"severity": int(msg.severity), "text": text.strip("\x00")})

    @staticmethod
    def is_sample(msg: Any) -> bool:
        return bool(msg.get_type() == "DEBUG_VECT" and msg.name == SAMPLE_NAME)

    # ---------- команды ----------
    def _require_link(self) -> MavlinkLink:
        if self.link is None or not self.t.connected:
            raise DeviceError(tr("Device not connected", "Устройство не подключено"))
        return self.link

    async def _command_nowait(self, cmd: int, p1: float = 0, p2: float = 0, comp: int = 1) -> None:
        link = self._require_link()
        sysid = self.sysid
        link.send(lambda m: m.command_long_send(sysid, comp, cmd, 0, p1, p2, 0, 0, 0, 0, 0))

    async def command(
        self,
        cmd: int,
        params: tuple[float, ...] = (),
        comp: int = 1,
        timeout_s: float = 2.0,
        retries: int = 2,
    ) -> int:
        link = self._require_link()
        p = list(params) + [0.0] * (7 - len(params))
        sysid = self.sysid
        for attempt in range(retries + 1):
            fut: asyncio.Future[int] = self._loop.create_future()
            self._acks[(comp, cmd)] = fut

            def send(m: Any, a: int = attempt) -> None:
                m.command_long_send(sysid, comp, cmd, a, *p)

            link.send(send)
            try:
                return await asyncio.wait_for(fut, timeout_s)
            except TimeoutError:
                self._acks.pop((comp, cmd), None)
        raise DeviceError(
            tr(
                "The device did not confirm the command — check the link",
                "Устройство не подтвердило команду — проверьте связь",
            )
        )

    async def _expect_ok(self, cmd: int, params: tuple[float, ...], what: str, comp: int = 1) -> None:
        result = await self.command(cmd, params, comp=comp)
        if result != ml.MAV_RESULT_ACCEPTED:
            raise DeviceError(
                f"{what}: {tr('the device refused', 'устройство отказалось')} ({tr('code', 'код')} {result})"
            )

    async def set_mode(self, name: str, timeout_s: float = 3.0) -> None:
        number = mode_number(self.family, name)
        await self._expect_ok(
            ml.MAV_CMD_DO_SET_MODE,
            (ml.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED, number),
            f"{tr('Mode', 'Режим')} {name}",
        )
        deadline = time.monotonic() + timeout_s
        while self.t.mode != name:
            if time.monotonic() > deadline:
                raise DeviceError(
                    tr(f"The device did not switch to {name} mode", f"Устройство не перешло в режим {name}")
                )
            await asyncio.sleep(0.05)

    async def arm(self) -> None:
        await self._expect_ok(ml.MAV_CMD_COMPONENT_ARM_DISARM, (1,), tr("Arming motors", "Запуск моторов"))

    async def takeoff(self, alt_m: float) -> None:
        await self._expect_ok(ml.MAV_CMD_NAV_TAKEOFF, (0, 0, 0, 0, 0, 0, alt_m), tr("Takeoff", "Взлёт"))

    async def set_mission_current(self, seq: int) -> None:
        await self._expect_ok(
            ml.MAV_CMD_DO_SET_MISSION_CURRENT, (seq,), tr("Jump to waypoint", "Переход к точке маршрута")
        )

    async def upload_mission(self, items: list[MissionItemSpec], timeout_s: float = 3.0) -> None:
        """Протокол загрузки миссии MAVLink: COUNT → (REQUEST_INT → ITEM_INT)… → ACK."""
        link = self._require_link()
        sysid = self.sysid
        while not self._mission_requests.empty():
            self._mission_requests.get_nowait()
        count = len(items)
        link.send(lambda m: m.mission_count_send(sysid, 1, count, 0))
        while True:
            try:
                msg = await asyncio.wait_for(self._mission_requests.get(), timeout_s)
            except TimeoutError as exc:
                raise DeviceError(
                    tr(
                        "Route upload failed: the device stopped responding",
                        "Маршрут не загрузился: устройство перестало отвечать",
                    )
                ) from exc
            if msg.get_type() == "MISSION_ACK":
                if msg.type == ml.MAV_MISSION_ACCEPTED:
                    return
                raise DeviceError(
                    tr(
                        f"The device rejected the route (code {msg.type})",
                        f"Устройство отклонило маршрут (код {msg.type})",
                    )
                )
            seq = int(msg.seq)
            if not 0 <= seq < count:
                continue
            it = items[seq]

            def send_item(m: Any, s: int = seq, it: MissionItemSpec = it) -> None:
                m.mission_item_int_send(
                    sysid,
                    1,
                    s,
                    it.frame,
                    it.command,
                    0,
                    1,
                    it.param1,
                    it.param2,
                    it.param3,
                    it.param4,
                    round(it.lat * 1e7),
                    round(it.lon * 1e7),
                    it.alt,
                    0,
                )

            link.send(send_item)

    async def ground_balance(self) -> None:
        await self._expect_ok(
            CMD_GROUND_BALANCE, (), tr("Ground balance", "Балансировка"), comp=SENSOR_COMPONENT_ID
        )

    async def set_sensitivity(self, level: int) -> None:
        await self._expect_ok(
            CMD_SET_SENSITIVITY,
            (float(level),),
            tr("Sensitivity", "Чувствительность"),
            comp=SENSOR_COMPONENT_ID,
        )

    # ---------- аварийные действия: без проверок состояния поиска ----------
    async def return_home(self) -> None:
        await self.set_mode("RTL")

    async def hold(self) -> None:
        await self.set_mode("LOITER" if self.family == "copter" else "HOLD")

    async def land_or_stop(self) -> None:
        await self.set_mode("LAND" if self.family == "copter" else "HOLD")
