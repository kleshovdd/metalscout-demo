"""Маршрут поиска → миссия ArduPilot.

Раскладка пунктов (номер пункта = seq):

    0          точка старта (ArduPilot перезаписывает её своим home)
    1          DO_CHANGE_SPEED — скорость перелёта до первой полосы
    [2]        NAV_TAKEOFF (только дрон)
    base       начало первой оставшейся полосы
    base+1     DO_CHANGE_SPEED — рабочая скорость
    base+2+2k  начало полосы k (кроме первой) · base+3+2k — конец полосы k
    последний  NAV_RETURN_TO_LAUNCH

Продолжение после смены батареи — это новая миссия с оставшихся полос, а не «перемотка»
старой: так скорость и высота всегда заданы явно.
"""

from __future__ import annotations

from dataclasses import dataclass

from metalscout.device.ardupilot import MissionItemSpec, ml
from metalscout.device.profiles import DeviceKind, DeviceProfile
from metalscout.geo import LatLon
from metalscout.planning.route import Lane


@dataclass(frozen=True)
class BuiltMission:
    items: list[MissionItemSpec]
    first_lane: int
    lane_end_seq: dict[int, int]  # seq конца полосы → индекс полосы
    lane_start_seq: dict[int, int]  # seq начала полосы → индекс полосы


def build_mission(lanes: list[Lane], from_lane: int, profile: DeviceProfile, home: LatLon) -> BuiltMission:
    remaining = lanes[from_lane:]
    if not remaining:
        raise ValueError("Нет оставшихся полос")
    drone = profile.kind == DeviceKind.DRONE
    frame = ml.MAV_FRAME_GLOBAL_TERRAIN_ALT if drone else ml.MAV_FRAME_GLOBAL_RELATIVE_ALT
    alt = profile.search_alt_m if drone else 0.0
    items: list[MissionItemSpec] = [
        MissionItemSpec(ml.MAV_CMD_NAV_WAYPOINT, lat=home.lat, lon=home.lon),
        MissionItemSpec(ml.MAV_CMD_DO_CHANGE_SPEED, param1=1, param2=profile.transit_speed_mps, param3=-1),
    ]
    if drone:
        items.append(
            MissionItemSpec(
                ml.MAV_CMD_NAV_TAKEOFF, frame=ml.MAV_FRAME_GLOBAL_RELATIVE_ALT, alt=profile.search_alt_m
            )
        )
    start_seq: dict[int, int] = {}
    end_seq: dict[int, int] = {}
    for k, lane in enumerate(remaining):
        start_seq[len(items)] = lane.index
        items.append(
            MissionItemSpec(
                ml.MAV_CMD_NAV_WAYPOINT, frame=frame, lat=lane.start.lat, lon=lane.start.lon, alt=alt
            )
        )
        if k == 0:
            items.append(
                MissionItemSpec(
                    ml.MAV_CMD_DO_CHANGE_SPEED, param1=1, param2=profile.search_speed_mps, param3=-1
                )
            )
        end_seq[len(items)] = lane.index
        items.append(
            MissionItemSpec(ml.MAV_CMD_NAV_WAYPOINT, frame=frame, lat=lane.end.lat, lon=lane.end.lon, alt=alt)
        )
    items.append(MissionItemSpec(ml.MAV_CMD_NAV_RETURN_TO_LAUNCH))
    return BuiltMission(items=items, first_lane=from_lane, lane_end_seq=end_seq, lane_start_seq=start_seq)
