"""Чтение и запись поисков, находок и измерений."""

from __future__ import annotations

import json
from typing import Any

from metalscout.detection.processor import FindState, GeoSample
from metalscout.detection.targets import category_for
from metalscout.device.profiles import DeviceKind
from metalscout.geo import LatLon
from metalscout.planning.route import Route
from metalscout.session.models import Find, FindStatus, Session, SessionState, WaitReason
from metalscout.storage.db import Database, dumps, now_iso


class Repository:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ---------- поиски ----------
    def create_session(self, name: str, kind: DeviceKind, area: list[LatLon], route: Route) -> Session:
        ts = now_iso()
        sid = self.db.execute(
            "INSERT INTO sessions (name, device_kind, area_json, route_json, state, lanes_total, "
            "created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                name,
                kind.value,
                dumps([p.model_dump() for p in area]),
                route.model_dump_json(),
                SessionState.PLANNED.value,
                len(route.lanes),
                ts,
                ts,
            ),
        )
        session = self.get_session(sid)
        assert session is not None
        return session

    def _session(self, row: dict[str, Any]) -> Session:
        finds = self.db.one("SELECT COUNT(*) AS n FROM finds WHERE session_id = ?", (row["id"],))
        return Session(
            id=row["id"],
            name=row["name"],
            device_kind=DeviceKind(row["device_kind"]),
            area=[LatLon(**p) for p in json.loads(row["area_json"])],
            route=Route.model_validate_json(row["route_json"]),
            state=SessionState(row["state"]),
            state_reason=WaitReason(row["state_reason"]) if row["state_reason"] else None,
            next_lane=row["next_lane"],
            lanes_total=row["lanes_total"],
            coverage_pct=round(row["coverage_pct"], 1),
            batteries_used=row["batteries_used"],
            finds_count=int(finds["n"]) if finds else 0,
            created_at=row["created_at"],
            started_at=row["started_at"],
            finished_at=row["finished_at"],
        )

    def get_session(self, sid: int) -> Session | None:
        row = self.db.one("SELECT * FROM sessions WHERE id = ?", (sid,))
        return self._session(row) if row else None

    def list_sessions(self) -> list[Session]:
        return [self._session(r) for r in self.db.all("SELECT * FROM sessions ORDER BY id DESC")]

    def active_session(self) -> Session | None:
        row = self.db.one(
            "SELECT * FROM sessions WHERE state NOT IN ('completed', 'cancelled', 'planned') "
            "ORDER BY id DESC LIMIT 1"
        )
        return self._session(row) if row else None

    def update_session(self, sid: int, **fields: Any) -> None:
        fields["updated_at"] = now_iso()
        cols = ", ".join(f"{k} = ?" for k in fields)
        values = [v.value if hasattr(v, "value") else v for v in fields.values()]
        self.db.execute(f"UPDATE sessions SET {cols} WHERE id = ?", (*values, sid))

    def delete_session(self, sid: int) -> None:
        self.db.execute("DELETE FROM sessions WHERE id = ?", (sid,))

    # ---------- находки ----------
    def _find(self, row: dict[str, Any]) -> Find:
        return Find(
            id=row["id"],
            session_id=row["session_id"],
            number=row["number"],
            lat=row["lat"],
            lon=row["lon"],
            strength=row["strength"],
            target_id=row["target_id"],
            category=category_for(row["target_id"]),  # на языке интерфейса, а не записи
            depth_cm=row["depth_cm"],
            passes=row["passes"],
            status=FindStatus(row["status"]),
            note=row["note"],
            created_at=row["created_at"],
        )

    def upsert_find(self, sid: int, f: FindState) -> Find:
        ts = now_iso()
        self.db.execute(
            "INSERT INTO finds (session_id, number, lat, lon, strength, target_id, category, depth_cm, "
            "passes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT (session_id, number) DO UPDATE SET lat = excluded.lat, lon = excluded.lon, "
            "strength = excluded.strength, target_id = excluded.target_id, category = excluded.category, "
            "depth_cm = excluded.depth_cm, passes = excluded.passes, updated_at = excluded.updated_at",
            (sid, f.id, f.lat, f.lon, f.strength, f.target_id, f.category, f.depth_cm, f.passes, ts, ts),
        )
        row = self.db.one("SELECT * FROM finds WHERE session_id = ? AND number = ?", (sid, f.id))
        assert row is not None
        return self._find(row)

    def list_finds(self, sid: int) -> list[Find]:
        rows = self.db.all("SELECT * FROM finds WHERE session_id = ? ORDER BY number", (sid,))
        return [self._find(r) for r in rows]

    def update_find(self, find_id: int, status: FindStatus | None, note: str | None) -> Find | None:
        if status is not None:
            self.db.execute(
                "UPDATE finds SET status = ?, updated_at = ? WHERE id = ?", (status.value, now_iso(), find_id)
            )
        if note is not None:
            self.db.execute(
                "UPDATE finds SET note = ?, updated_at = ? WHERE id = ?", (note, now_iso(), find_id)
            )
        row = self.db.one("SELECT * FROM finds WHERE id = ?", (find_id,))
        return self._find(row) if row else None

    def max_find_number(self, sid: int) -> int:
        row = self.db.one("SELECT COALESCE(MAX(number), 0) AS n FROM finds WHERE session_id = ?", (sid,))
        return int(row["n"]) if row else 0

    # ---------- измерения ----------
    def add_samples(self, sid: int, samples: list[GeoSample]) -> None:
        self.db.executemany(
            "INSERT INTO samples (session_id, t_ms, lat, lon, signal, excess, target_id, coil_h, valid) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                (sid, s.t_ms, s.lat, s.lon, s.signal, s.excess, s.target_id, s.coil_h, int(s.valid))
                for s in samples
            ],
        )

    def samples(self, sid: int, valid_only: bool = False) -> list[dict[str, Any]]:
        where = "session_id = ?" + (" AND valid = 1" if valid_only else "")
        return self.db.all(
            f"SELECT lat, lon, excess, target_id, valid FROM samples WHERE {where} ORDER BY rowid", (sid,)
        )
