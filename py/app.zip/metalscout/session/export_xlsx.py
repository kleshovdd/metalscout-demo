"""Выгрузка в Excel: цветная таблица находок — сразу видно, что выкопано, что пусто, что забыто.

Цвета строк совпадают с отметками в приложении: выкопано — зелёный, пусто — серый,
пропущено — жёлтый, не проверено — без заливки.
"""

from __future__ import annotations

import io
from collections import Counter
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from metalscout.i18n import get_lang, tr
from metalscout.session.models import Find, Session


def _status(value: str) -> str:
    return {
        "new": tr("Not checked", "Не проверено"),
        "dug": tr("Dug up", "Выкопано"),
        "empty": tr("Nothing", "Пусто"),
        "skipped": tr("Skipped", "Пропущено"),
    }[value]


STATUS_FILL = {
    "dug": "D7F2E3",
    "empty": "E3E6E8",
    "skipped": "FCEFD2",
    "new": None,
}
STATUS_INK = {"dug": "1E7A4C", "empty": "5C686B", "skipped": "9A6A12", "new": "1B1F21"}
ORDER = {"new": 0, "dug": 1, "skipped": 2, "empty": 3}


def _headers() -> list[tuple[str, int]]:
    return [
        ("№" if get_lang() == "ru" else "#", 6),
        (tr("Status", "Статус"), 15),
        (tr("Metal type", "Тип металла"), 26),
        (tr("Target ID", "ID цели"), 9),
        (tr("Strength", "Сила"), 8),
        (tr("Depth, cm", "Глубина, см"), 12),
        (tr("Passes", "Проходов"), 10),
        (tr("Latitude", "Широта"), 14),
        (tr("Longitude", "Долгота"), 14),
        (tr("Map", "Карта"), 14),
        (tr("Note", "Заметка"), 30),
    ]


THIN = Side(style="thin", color="D5DADC")
BORDER = Border(bottom=THIN)
HEAD_FILL = PatternFill("solid", fgColor="13191C")


def _fill(color: str | None) -> PatternFill:
    return PatternFill("solid", fgColor=color) if color else PatternFill()


def _sheet_finds(ws: Worksheet, session: Session, finds: list[Find]) -> None:
    ws.title = tr("Finds", "Находки")
    ws.sheet_view.showGridLines = False
    ws["A1"] = session.name
    ws["A1"].font = Font(size=16, bold=True)
    created = (
        datetime.fromisoformat(session.created_at)
        .astimezone()
        .strftime("%d.%m.%Y %H:%M" if get_lang() == "ru" else "%Y-%m-%d %H:%M")
    )
    counts = Counter(f.status.value for f in finds)
    area = session.route.estimate.area_m2
    ws["A2"] = tr(
        f"{created} · area {area:.0f} m² · coverage {session.coverage_pct:.0f}% · "
        f"{len(finds)} finds: dug up {counts['dug']}, nothing {counts['empty']}, "
        f"skipped {counts['skipped']}, not checked {counts['new']}",
        f"{created} · участок {area:.0f} м² · покрытие {session.coverage_pct:.0f}% · "
        f"находок {len(finds)}: выкопано {counts['dug']}, пусто {counts['empty']}, "
        f"пропущено {counts['skipped']}, не проверено {counts['new']}",
    )
    ws["A2"].font = Font(color="5C686B")

    # Легенда цветов.
    col = 1
    for status in ("dug", "empty", "skipped", "new"):
        cell = ws.cell(row=3, column=col, value=_status(status))
        cell.fill = _fill(STATUS_FILL[status])
        cell.font = Font(bold=True, color=STATUS_INK[status], size=10)
        cell.alignment = Alignment(horizontal="center")
        ws.merge_cells(start_row=3, start_column=col, end_row=3, end_column=col + 1)
        col += 2

    header_row = 5
    headers = _headers()
    for i, (title, width) in enumerate(headers, start=1):
        c = ws.cell(row=header_row, column=i, value=title)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = HEAD_FILL
        c.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[header_row].height = 22

    rows = sorted(finds, key=lambda f: (ORDER[f.status.value], -f.strength))
    for r, f in enumerate(rows, start=header_row + 1):
        status = f.status.value
        values = [
            f.number,
            _status(status),
            f.category,
            f.target_id,
            f.strength,
            f.depth_cm,
            f.passes,
            f.lat,
            f.lon,
            tr("Open", "Открыть"),
            f.note,
        ]
        for i, v in enumerate(values, start=1):
            c = ws.cell(row=r, column=i, value=v)
            c.fill = _fill(STATUS_FILL[status])
            c.border = BORDER
        ws.cell(row=r, column=2).font = Font(bold=True, color=STATUS_INK[status])
        ws.cell(row=r, column=8).number_format = "0.00000000"
        ws.cell(row=r, column=9).number_format = "0.00000000"
        link = ws.cell(row=r, column=10)
        link.hyperlink = f"https://maps.google.com/?q={f.lat:.8f},{f.lon:.8f}"
        link.font = Font(color="1F6FB2", underline="single")

    last = header_row + max(1, len(rows))
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
    ws.auto_filter.ref = f"A{header_row}:{get_column_letter(len(headers))}{last}"


def _sheet_summary(ws: Worksheet, finds: list[Find]) -> None:
    ws.sheet_view.showGridLines = False
    ws["A1"] = tr("Summary", "Сводка")
    ws["A1"].font = Font(size=14, bold=True)
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 10
    row = 3
    ws.cell(row=row, column=1, value=tr("By mark", "По отметкам")).font = Font(bold=True)
    counts = Counter(f.status.value for f in finds)
    for status in ("new", "dug", "empty", "skipped"):
        row += 1
        a = ws.cell(row=row, column=1, value=_status(status))
        b = ws.cell(row=row, column=2, value=counts[status])
        for c in (a, b):
            c.fill = _fill(STATUS_FILL[status])
    row += 2
    ws.cell(row=row, column=1, value=tr("By metal type", "По типу металла")).font = Font(bold=True)
    for category, n in Counter(f.category for f in finds).most_common():
        row += 1
        ws.cell(row=row, column=1, value=category)
        ws.cell(row=row, column=2, value=n)


def to_xlsx(session: Session, finds: list[Find]) -> bytes:
    wb = Workbook()
    ws = wb.active
    assert ws is not None
    _sheet_finds(ws, session, finds)
    _sheet_summary(wb.create_sheet(tr("Summary", "Сводка")), finds)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
