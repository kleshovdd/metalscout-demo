"""Модели поиска, находок и предстартовой проверки (то, что видит интерфейс)."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import BaseModel

from metalscout.device.profiles import DeviceKind
from metalscout.geo import LatLon
from metalscout.planning.route import Route


class SessionState(StrEnum):
    PLANNED = "planned"  # участок и маршрут готовы, поиск не начинался
    STARTING = "starting"  # загрузка маршрута, взлёт
    SEARCHING = "searching"  # идёт по полосам
    PAUSED = "paused"  # висит / стоит по команде пользователя
    RETURNING = "returning"  # возвращается к точке старта
    WAITING = "waiting"  # на земле, ждёт «Продолжить» (батарея, остановка, failsafe)
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class WaitReason(StrEnum):
    BATTERY = "battery"  # пора менять батарею
    USER = "user"  # пользователь вернул устройство
    INTERRUPTED = "interrupted"  # автопилот или пилот прервали поиск (связь, пульт)
    DONE = "done"  # маршрут пройден, едет/летит домой


class FindStatus(StrEnum):
    NEW = "new"
    DUG = "dug"  # выкопано, что-то нашлось
    EMPTY = "empty"  # пусто / ложный сигнал
    SKIPPED = "skipped"


class Find(BaseModel):
    id: int
    session_id: int
    number: int
    lat: float
    lon: float
    strength: int
    target_id: int | None
    category: str
    depth_cm: int | None
    passes: int
    status: FindStatus
    note: str
    created_at: str


class Session(BaseModel):
    id: int
    name: str
    device_kind: DeviceKind
    area: list[LatLon]
    route: Route
    state: SessionState
    state_reason: WaitReason | None
    next_lane: int
    lanes_total: int
    coverage_pct: float
    batteries_used: int
    finds_count: int
    created_at: str
    started_at: str | None
    finished_at: str | None


class CheckStatus(StrEnum):
    OK = "ok"
    WARN = "warn"
    FAIL = "fail"


class Check(BaseModel):
    id: str
    title: str
    status: CheckStatus
    detail: str
    action: Literal["ground_balance"] | None = None


class Preflight(BaseModel):
    ready: bool
    checks: list[Check]
