"""Сценарий поиска: старт → полосы → возврат на смену батареи → продолжение → итог.

Контроллер не управляет полётом: маршрут и безопасность исполняет автопилот. Контроллер
загружает миссию, следит за прогрессом и батареей, обрабатывает сигнал и сохраняет всё в
базу, чтобы перезапуск программы не терял поиск.
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from typing import Any

from metalscout.detection.processor import FindState, GeoSample, RawSample, SignalProcessor
from metalscout.detection.targets import excess_from_strength
from metalscout.device.ardupilot import ArduPilotDevice, DeviceError, EventSink
from metalscout.device.mission import BuiltMission, build_mission
from metalscout.device.profiles import PROFILES, DeviceKind, DeviceProfile
from metalscout.geo import LatLon, LocalFrame, distance_m
from metalscout.i18n import tr
from metalscout.session.models import (
    Check,
    CheckStatus,
    Preflight,
    Session,
    SessionState,
    WaitReason,
)
from metalscout.session.repo import Repository
from metalscout.storage.db import now_iso

log = logging.getLogger(__name__)

MAX_START_DISTANCE_M = 300.0


class SessionError(RuntimeError):
    """Действие невозможно в текущем состоянии (текст — для пользователя)."""


class SessionController:
    def __init__(self, device: ArduPilotDevice, repo: Repository, emit: EventSink) -> None:
        self.device = device
        self.repo = repo
        self.emit = emit
        self.session: Session | None = None
        self.processor: SignalProcessor | None = None
        self.mission: BuiltMission | None = None
        self._samples_buf: list[GeoSample] = []
        self._ui_buf: list[GeoSample] = []
        self._tick_task: asyncio.Task[None] | None = None
        self._battery_mark: tuple[float, float] | None = None  # (время, заряд) для расхода
        self._busy = asyncio.Lock()
        device.add_listener(self._on_message)

    # ---------- жизненный цикл ----------
    def start_background(self) -> None:
        if self._tick_task is None:
            self._tick_task = asyncio.create_task(self._tick_loop())

    async def stop_background(self) -> None:
        if self._tick_task is not None:
            self._tick_task.cancel()
            self._tick_task = None
        self._flush()

    def restore(self) -> None:
        """После перезапуска программы: продолжить незавершённый поиск в режиме ожидания."""
        active = self.repo.active_session()
        if active is None:
            return
        if active.state in (
            SessionState.STARTING,
            SessionState.SEARCHING,
            SessionState.PAUSED,
            SessionState.RETURNING,
        ):
            self.repo.update_session(
                active.id, state=SessionState.WAITING, state_reason=WaitReason.INTERRUPTED
            )
        self.activate(active.id)

    def activate(self, sid: int) -> Session:
        s = self.repo.get_session(sid)
        if s is None:
            raise SessionError(tr("Search not found", "Поиск не найден"))
        self.session = s
        self.processor = self._make_processor(s)
        for row in self.repo.samples(sid, valid_only=True):
            self.processor.coverage.mark(*self.processor.frame.to_local(row["lat"], row["lon"]))
        self._publish_session()
        return s

    def _make_processor(self, s: Session) -> SignalProcessor:
        origin = s.area[0]
        proc = SignalProcessor(
            LocalFrame(origin),
            PROFILES[s.device_kind],
            s.area,
            first_find_id=self.repo.max_find_number(s.id) + 1,
        )
        for f in self.repo.list_finds(s.id):
            e, n = proc.frame.to_local(f.lat, f.lon)
            proc.finds.append(
                FindState(
                    id=f.number,
                    east=e,
                    north=n,
                    lat=f.lat,
                    lon=f.lon,
                    peak=excess_from_strength(f.strength),
                    target_id=f.target_id,
                    passes=f.passes,
                    depth_cm=f.depth_cm,
                    category=f.category,
                    strength=f.strength,
                    weight=1.0,
                )
            )
        return proc

    @property
    def profile(self) -> DeviceProfile:
        assert self.session is not None
        return PROFILES[self.session.device_kind]

    def _set(self, state: SessionState, reason: WaitReason | None = None, **extra: Any) -> None:
        assert self.session is not None
        self.repo.update_session(self.session.id, state=state, state_reason=reason, **extra)
        self._reload()

    def _reload(self) -> None:
        assert self.session is not None
        s = self.repo.get_session(self.session.id)
        assert s is not None
        self.session = s
        self._publish_session()

    def _publish_session(self) -> None:
        if self.session is not None:
            self.emit("session", self.session.model_dump(mode="json"))

    def _require(self, *states: SessionState) -> Session:
        if self.session is None:
            raise SessionError(tr("No active search", "Нет активного поиска"))
        if states and self.session.state not in states:
            raise SessionError(tr("This action is not available now", "Это действие сейчас недоступно"))
        return self.session

    # ---------- предстартовая проверка ----------
    def preflight(self) -> Preflight:
        t = self.device.t
        checks: list[Check] = []
        s = self.session

        def add(id_: str, title: str, status: CheckStatus, detail: str, action: Any = None) -> None:
            checks.append(Check(id=id_, title=title, status=status, detail=detail, action=action))

        link = tr("Link to the device", "Связь с устройством")
        if t.connected and t.link_ok:
            add("link", link, CheckStatus.OK, tr("Device is online", "Устройство на связи"))
        else:
            add(
                "link",
                link,
                CheckStatus.FAIL,
                tr("No link — connect the device", "Нет связи — подключите устройство"),
            )
        if s is not None and t.kind is not None and t.kind != s.device_kind:
            add(
                "kind",
                tr("Device type", "Тип устройства"),
                CheckStatus.FAIL,
                tr("The route was planned for another device", "Маршрут построен для другого устройства"),
            )
        gps = tr("GPS accuracy", "Точность GPS")
        sats = f"{t.gps_sats} {tr('satellites', 'спутников')}"
        if t.gps_fix >= 6:
            add("gps", gps, CheckStatus.OK, f"RTK: {tr('centimetres', 'сантиметры')} · {sats}")
        elif t.gps_fix == 5:
            # RTK без фиксации (~10–20 см) для поиска достаточно — не пугаем пользователя.
            add("gps", gps, CheckStatus.OK, f"RTK · {sats}")
        elif t.gps_fix >= 3:
            add(
                "gps",
                gps,
                CheckStatus.WARN,
                tr(
                    "No RTK: 1–2 m. Find marks will be imprecise",
                    "Без RTK: 1–2 м. Метки находок будут неточными",
                ),
            )
        else:
            add(
                "gps",
                gps,
                CheckStatus.FAIL,
                tr("No satellites. Move to an open area", "Нет спутников. Выйдите на открытое место"),
            )
        bat = t.battery_pct
        battery = tr("Battery", "Батарея")
        if bat is None:
            add("battery", battery, CheckStatus.FAIL, tr("No battery data", "Нет данных о батарее"))
        elif bat >= 90:
            add("battery", battery, CheckStatus.OK, f"{bat:.0f} %")
        elif bat >= 45:
            add(
                "battery",
                battery,
                CheckStatus.WARN,
                f"{bat:.0f} % — {tr('will return for a swap earlier', 'вернётся на смену раньше')}",
            )
        else:
            add(
                "battery",
                battery,
                CheckStatus.FAIL,
                f"{bat:.0f} % — {tr('replace the battery', 'замените батарею')}",
            )
        sensor = tr("Metal detector", "Металлоискатель")
        if t.sensor_online:
            add("sensor", sensor, CheckStatus.OK, tr("Online", "На связи"))
        else:
            add(
                "sensor",
                sensor,
                CheckStatus.FAIL,
                tr("Not responding — check the sensor cable", "Не отвечает — проверьте кабель датчика"),
            )
        balance = tr("Ground balance", "Балансировка по грунту")
        if t.sensor_balanced:
            add("balance", balance, CheckStatus.OK, tr("Done", "Выполнена"))
        else:
            add(
                "balance",
                balance,
                CheckStatus.FAIL,
                tr(
                    "The ground itself “rings” (minerals, salt, moisture). "
                    "Without balancing you get false finds. Needed after every power-on",
                    "Земля сама «звенит» (минералы, соль, влага). Без балансировки — ложные находки. "
                    "Нужна после каждого включения",
                ),
                "ground_balance",
            )
        if t.kind == DeviceKind.DRONE:
            rangefinder = tr("Coil rangefinder", "Дальномер катушки")
            if t.coil_height_m is not None:
                add(
                    "rangefinder",
                    rangefinder,
                    CheckStatus.OK,
                    f"{t.coil_height_m:.2f} {tr('m to the ground', 'м до земли')}",
                )
            else:
                add(
                    "rangefinder",
                    rangefinder,
                    CheckStatus.FAIL,
                    tr("No data — cannot fly low without it", "Нет данных — без него низко не полететь"),
                )
        if s is not None and t.lat is not None and t.lon is not None:
            d = min(distance_m(LatLon(lat=t.lat, lon=t.lon), p) for p in s.area)
            distance = tr("Distance to the area", "Расстояние до участка")
            if d <= MAX_START_DISTANCE_M:
                add("distance", distance, CheckStatus.OK, f"{d:.0f} {tr('m', 'м')}")
            else:
                add(
                    "distance",
                    distance,
                    CheckStatus.FAIL,
                    f"{d:.0f} {tr('m — bring the device closer', 'м — поднесите устройство ближе')}",
                )
        if t.armed:
            add(
                "armed",
                tr("Motors", "Моторы"),
                CheckStatus.WARN,
                tr("Motors are already running", "Моторы уже запущены"),
            )
        ready = all(c.status != CheckStatus.FAIL for c in checks)
        return Preflight(ready=ready, checks=checks)

    # ---------- действия пользователя ----------
    async def start(self) -> Session:
        async with self._busy:
            s = self._require(SessionState.PLANNED, SessionState.WAITING)
            pf = self.preflight()
            if not pf.ready:
                failed = next(c for c in pf.checks if c.status == CheckStatus.FAIL)
                raise SessionError(f"{failed.title}: {failed.detail}")
            if s.next_lane >= s.lanes_total:
                raise SessionError(tr("All lanes are already done", "Все полосы уже пройдены"))
            t = self.device.t
            home = t.home or LatLon(lat=t.lat or 0.0, lon=t.lon or 0.0)
            mission = build_mission(s.route.lanes, s.next_lane, self.profile, home)
            first = s.state == SessionState.PLANNED
            self._set(SessionState.STARTING)
            try:
                await self.device.upload_mission(mission.items)
                self.mission = mission
                if self.device.family == "copter":
                    await self.device.set_mode("GUIDED")
                    await self.device.arm()
                    await self.device.set_mode("AUTO")
                else:
                    await self.device.set_mode("HOLD")
                    await self.device.arm()
                    await self.device.set_mode("AUTO")
            except DeviceError:
                self._set(
                    SessionState.WAITING if not first else SessionState.PLANNED,
                    None if first else WaitReason.INTERRUPTED,
                )
                raise
            assert self.processor is not None
            self.processor.recording = False
            self._battery_mark = None
            extra: dict[str, Any] = {"batteries_used": s.batteries_used + 1}
            if first:
                extra["started_at"] = now_iso()
            self._set(SessionState.SEARCHING, **extra)
            self.emit("notice", {"level": "info", "text": tr("Search started", "Поиск начался")})
            return self._require()

    async def pause(self) -> Session:
        async with self._busy:
            self._require(SessionState.SEARCHING)
            await self.device.hold()
            self._set(SessionState.PAUSED)
            return self._require()

    async def resume(self) -> Session:
        async with self._busy:
            self._require(SessionState.PAUSED)
            await self.device.set_mode("AUTO")
            self._set(SessionState.SEARCHING)
            return self._require()

    async def return_home(self) -> Session:
        async with self._busy:
            self._require(SessionState.SEARCHING, SessionState.PAUSED, SessionState.STARTING)
            await self.device.return_home()
            self._set(SessionState.RETURNING, WaitReason.USER)
            return self._require()

    def on_emergency(self) -> None:
        """Пользователь нажал аварийную кнопку в обход сценария: поиск больше не ведём."""
        s = self.session
        if s is not None and s.state in (SessionState.SEARCHING, SessionState.PAUSED, SessionState.STARTING):
            self._set(SessionState.RETURNING, WaitReason.USER)

    async def finish(self) -> Session:
        s = self._require()
        if s.state in (
            SessionState.SEARCHING,
            SessionState.PAUSED,
            SessionState.STARTING,
            SessionState.RETURNING,
        ):
            raise SessionError(
                tr(
                    "First bring the device back to the start point",
                    "Сначала верните устройство на точку старта",
                )
            )
        self._flush()
        state = SessionState.COMPLETED if s.started_at else SessionState.CANCELLED
        self._set(state, None, finished_at=now_iso())
        return self._require()

    # ---------- телеметрия ----------
    def _on_message(self, msg: Any) -> None:
        proc = self.processor
        if proc is None:
            return
        kind = msg.get_type()
        if kind == "GLOBAL_POSITION_INT":
            hdg = msg.hdg / 100 if msg.hdg != 65535 else 0.0
            speed = math.hypot(msg.vx, msg.vy) / 100
            proc.on_pose(int(msg.time_boot_ms), msg.lat / 1e7, msg.lon / 1e7, hdg, speed)
        elif kind == "ATTITUDE":
            proc.on_yaw_rate(float(msg.yawspeed))
        elif kind == "DISTANCE_SENSOR":
            proc.on_coil_height(int(msg.time_boot_ms), msg.current_distance / 100)
        elif ArduPilotDevice.is_sample(msg):
            geo, finds = proc.on_sample(
                RawSample(int(msg.time_usec // 1000), float(msg.x), float(msg.y), float(msg.z))
            )
            if self.session is not None and self.session.state in (
                SessionState.SEARCHING,
                SessionState.PAUSED,
                SessionState.RETURNING,
                SessionState.STARTING,
            ):
                self._samples_buf.extend(geo)
            self._ui_buf.extend(geo)
            for f in finds:
                if self.session is not None:
                    stored = self.repo.upsert_find(self.session.id, f)
                    self.emit("find", stored.model_dump(mode="json"))
        elif kind == "MISSION_ITEM_REACHED":
            self._on_reached(int(msg.seq))
        if kind in ("MISSION_CURRENT", "MISSION_ITEM_REACHED", "HEARTBEAT"):
            # Запись покрытия переключаем в том же порядке, что идут сообщения: при ускоренном
            # симуляторе или медленном компьютере проверка раз в 0,2 с отстаёт на секунды.
            self._update_recording()

    def _on_reached(self, seq: int) -> None:
        m = self.mission
        s = self.session
        if m is None or s is None or s.state != SessionState.SEARCHING:
            return
        if seq in m.lane_end_seq:
            lane = m.lane_end_seq[seq]
            self.repo.update_session(s.id, next_lane=lane + 1)
            self._reload()

    def _update_recording(self) -> None:
        """Запись покрытия — только на полосе: между её началом и концом."""
        proc = self.processor
        m = self.mission
        s = self.session
        if proc is None:
            return
        if m is None or s is None or s.state != SessionState.SEARCHING or self.device.t.mode != "AUTO":
            proc.recording = False
            return
        seq = self.device.t.mission_seq
        # Текущая цель — конец полосы, значит идём по полосе.
        proc.recording = seq in m.lane_end_seq

    # ---------- фоновые проверки ----------
    async def _tick_loop(self) -> None:
        last_flush = time.monotonic()
        while True:
            await asyncio.sleep(0.2)
            try:
                self._update_recording()
                if self._ui_buf:
                    self.emit("samples", {"items": [_sample_json(g) for g in self._ui_buf]})
                    self._ui_buf.clear()
                now = time.monotonic()
                if now - last_flush > 1.0:
                    last_flush = now
                    self._flush()
                    await self._supervise()
            except Exception:
                log.exception("Ошибка фоновой проверки поиска")

    def _flush(self) -> None:
        s = self.session
        if s is None or not self._samples_buf:
            return
        self.repo.add_samples(s.id, self._samples_buf)
        self._samples_buf.clear()
        if self.processor is not None:
            pct = self.processor.coverage.percent
            if abs(pct - s.coverage_pct) >= 0.1:
                self.repo.update_session(s.id, coverage_pct=pct)
                self._reload()

    async def _supervise(self) -> None:
        s = self.session
        t = self.device.t
        if s is None or not t.connected or self._busy.locked():
            return
        if s.state == SessionState.SEARCHING:
            if s.next_lane >= s.lanes_total:
                self._set(SessionState.RETURNING, WaitReason.DONE)
                self.emit(
                    "notice",
                    {
                        "level": "success",
                        "text": tr(
                            "Area covered, the device is returning",
                            "Участок пройден, устройство возвращается",
                        ),
                    },
                )
                return
            if t.mode != "AUTO" and t.link_ok:
                # Автопилот сам ушёл из AUTO: failsafe по батарее/связи или пилот взял пульт.
                reason = WaitReason.BATTERY if (t.battery_pct or 100) < 30 else WaitReason.INTERRUPTED
                self._set(SessionState.RETURNING, reason)
                self.emit(
                    "notice",
                    {
                        "level": "warning",
                        "text": tr(
                            f"Search interrupted by the autopilot (mode {t.mode})",
                            f"Поиск прерван автопилотом (режим {t.mode})",
                        ),
                    },
                )
                return
            if self._battery_low():
                await self.device.return_home()
                self._set(SessionState.RETURNING, WaitReason.BATTERY)
                self.emit(
                    "notice",
                    {
                        "level": "warning",
                        "text": tr(
                            "Battery is only enough to return — returning",
                            "Батареи хватит только на возврат — возвращаюсь",
                        ),
                    },
                )
        elif s.state == SessionState.RETURNING and self._arrived_home():
            if s.state_reason == WaitReason.DONE or s.next_lane >= s.lanes_total:
                self._flush()
                self._set(SessionState.COMPLETED, None, finished_at=now_iso())
                self.emit("notice", {"level": "success", "text": tr("Search complete", "Поиск завершён")})
            else:
                self._set(SessionState.WAITING, s.state_reason or WaitReason.USER)
                if s.state_reason == WaitReason.BATTERY:
                    self.emit(
                        "notice",
                        {
                            "level": "info",
                            "text": tr(
                                "Replace the battery and press “Continue”",
                                "Замените батарею и нажмите «Продолжить»",
                            ),
                        },
                    )

    def _arrived_home(self) -> bool:
        t = self.device.t
        if self.device.family == "copter":
            return not t.armed
        if t.home is None or t.lat is None or t.lon is None:
            return not t.armed
        near = distance_m(t.home, LatLon(lat=t.lat, lon=t.lon)) < 2.5
        return (near and (t.speed_mps or 0) < 0.1) or not t.armed

    def _battery_low(self) -> bool:
        t = self.device.t
        if t.battery_pct is None or t.lat is None or t.lon is None:
            return False
        # Расход считаем по часам контроллера: в ускоренном симуляторе они идут быстрее
        # настенных, а на настоящем устройстве совпадают с ними.
        now = t.time_boot_ms / 1000
        if self._battery_mark is None or now < self._battery_mark[0]:
            self._battery_mark = (now, t.battery_pct)
            return False
        p = self.profile
        t0, b0 = self._battery_mark
        elapsed = now - t0
        measured = (b0 - t.battery_pct) / elapsed if elapsed > 20 and b0 > t.battery_pct else 0.0
        nominal = 100.0 / (p.endurance_min * 60.0)
        drain = max(measured, nominal)
        home = t.home or LatLon(lat=t.lat, lon=t.lon)
        dist = distance_m(home, LatLon(lat=t.lat, lon=t.lon))
        need = drain * (dist / p.transit_speed_mps + 30.0)
        return t.battery_pct - need <= p.battery_reserve_pct


def _sample_json(g: GeoSample) -> list[float | int | None]:
    return [round(g.lat, 7), round(g.lon, 7), round(g.excess, 3), int(g.target_id), int(g.valid)]
