"""Выгрузка находок: Excel, GPX (навигаторы, телефоны), KML (Google Earth), GeoJSON, CSV."""

from __future__ import annotations

import csv
import io
import json
from xml.sax.saxutils import escape

from metalscout.i18n import get_lang, tr
from metalscout.session.export_xlsx import to_xlsx
from metalscout.session.models import Find, Session

__all__ = ["to_csv", "to_geojson", "to_gpx", "to_kml", "to_xlsx"]


def _status(value: str) -> str:
    return {
        "new": tr("not checked", "не проверено"),
        "dug": tr("dug up", "выкопано"),
        "empty": tr("nothing", "пусто"),
        "skipped": tr("skipped", "пропущено"),
    }.get(value, value)


def _title(f: Find) -> str:
    return f"#{f.number} {f.category}"


def _desc(f: Find) -> str:
    parts = [f"{tr('Strength', 'Сила')} {f.strength}"]
    if f.target_id is not None:
        parts.append(f"ID {f.target_id}")
    if f.depth_cm is not None:
        parts.append(f"{tr('depth', 'глубина')} ≈ {f.depth_cm} {tr('cm', 'см')}")
    parts.append(_status(f.status.value))
    if f.note:
        parts.append(f.note)
    return " · ".join(parts)


def to_gpx(session: Session, finds: list[Find]) -> str:
    wpts = "\n".join(
        f'  <wpt lat="{f.lat:.8f}" lon="{f.lon:.8f}"><name>{escape(_title(f))}</name>'
        f"<desc>{escape(_desc(f))}</desc></wpt>"
        for f in finds
    )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<gpx version="1.1" creator="MetalScout" xmlns="http://www.topografix.com/GPX/1/1">\n'
        f"  <metadata><name>{escape(session.name)}</name></metadata>\n{wpts}\n</gpx>\n"
    )


def to_kml(session: Session, finds: list[Find]) -> str:
    marks = "\n".join(
        f"    <Placemark><name>{escape(_title(f))}</name><description>{escape(_desc(f))}</description>"
        f"<Point><coordinates>{f.lon:.8f},{f.lat:.8f},0</coordinates></Point></Placemark>"
        for f in finds
    )
    ring = " ".join(f"{p.lon:.8f},{p.lat:.8f},0" for p in [*session.area, session.area[0]])
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2">\n  <Document>\n'
        f"    <name>{escape(session.name)}</name>\n"
        f"    <Placemark><name>{tr('Area', 'Участок')}</name>"
        f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring}"
        "</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>\n"
        f"{marks}\n  </Document>\n</kml>\n"
    )


def to_geojson(session: Session, finds: list[Find]) -> str:
    features = [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[p.lon, p.lat] for p in [*session.area, session.area[0]]]],
            },
            "properties": {"kind": "area", "name": session.name},
        }
    ]
    for f in finds:
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [f.lon, f.lat]},
                "properties": {"kind": "find", **f.model_dump(mode="json", exclude={"lat", "lon"})},
            }
        )
    return json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False, indent=1)


def _num(value: float, digits: int) -> str:
    text = f"{value:.{digits}f}"
    return text.replace(".", ",") if get_lang() == "ru" else text


def to_csv(finds: list[Find]) -> str:
    """Таблица для Excel и Numbers с настройками языка интерфейса.

    Excel открывает CSV двойным щелчком в кодировке системы, а не UTF-8 (кириллица
    превращается в «кракозябры»), поэтому в начале метка UTF-8 (BOM). В русской локали Excel
    ждёт разделитель «;» и десятичную запятую («55,7059»), в английской — «,» и точку.
    """
    ru = get_lang() == "ru"
    buf = io.StringIO()
    buf.write("\ufeff")
    w = csv.writer(buf, delimiter=";" if ru else ",")
    w.writerow(
        [
            "номер",
            "широта",
            "долгота",
            "сила",
            "id_цели",
            "тип",
            "глубина_см",
            "проходов",
            "статус",
            "заметка",
        ]
        if ru
        else ["number", "lat", "lon", "strength", "target_id", "type", "depth_cm", "passes", "status", "note"]
    )
    for f in finds:
        w.writerow(
            [
                f.number,
                _num(f.lat, 8),
                _num(f.lon, 8),
                f.strength,
                f.target_id if f.target_id is not None else "",
                f.category,
                f.depth_cm if f.depth_cm is not None else "",
                f.passes,
                _status(f.status.value),
                f.note,
            ]
        )
    return buf.getvalue()
