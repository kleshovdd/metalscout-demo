"""Обработка сигнала металлоискателя: привязка к координатам, фон, всплески, находки.

Вход — сырые измерения датчика (время контроллера + сила + ID цели) и поза аппарата.
Выход — точки карты сигнала, покрытие и находки. Модуль не знает про MAVLink и базу.
"""

from __future__ import annotations

import math
import statistics
from collections import deque
from dataclasses import dataclass, field

from metalscout.device.profiles import DeviceProfile
from metalscout.geo import LatLon, LocalFrame, point_in_polygon

from .targets import category_for, strength_pct


@dataclass(frozen=True)
class Pose:
    t_ms: int
    east: float
    north: float
    yaw: float  # рад, 0 = север
    speed: float


@dataclass(frozen=True)
class RawSample:
    t_ms: int
    signal: float
    target_id: float
    ground: float


@dataclass(frozen=True)
class GeoSample:
    t_ms: int
    lat: float
    lon: float
    east: float
    north: float
    coil_h: float | None
    signal: float
    excess: float
    target_id: float
    valid: bool


@dataclass
class _PassHit:
    points: list[tuple[GeoSample, float]] = field(default_factory=list)


@dataclass
class FindState:
    id: int
    east: float
    north: float
    lat: float
    lon: float
    peak: float
    target_id: int | None
    passes: int
    depth_cm: int | None
    category: str
    strength: int
    weight: float
    tids: list[tuple[float, float]] = field(default_factory=list)


class PoseBuffer:
    def __init__(self, horizon_ms: int = 10_000) -> None:
        self._poses: deque[Pose] = deque()
        self.horizon_ms = horizon_ms

    def add(self, pose: Pose) -> None:
        if self._poses and pose.t_ms < self._poses[-1].t_ms - 1000:
            self._poses.clear()  # контроллер перезагрузился — время пошло с нуля
        self._poses.append(pose)
        while self._poses and self._poses[0].t_ms < pose.t_ms - self.horizon_ms:
            self._poses.popleft()

    @property
    def latest_t(self) -> int | None:
        return self._poses[-1].t_ms if self._poses else None

    def at(self, t_ms: int) -> Pose | None:
        poses = self._poses
        if not poses or t_ms < poses[0].t_ms or t_ms > poses[-1].t_ms + 200:
            return None
        prev = poses[0]
        for p in poses:
            if p.t_ms >= t_ms:
                if p.t_ms == prev.t_ms:
                    return p
                k = (t_ms - prev.t_ms) / (p.t_ms - prev.t_ms)
                dyaw = (p.yaw - prev.yaw + math.pi) % (2 * math.pi) - math.pi
                return Pose(
                    t_ms,
                    prev.east + (p.east - prev.east) * k,
                    prev.north + (p.north - prev.north) * k,
                    prev.yaw + dyaw * k,
                    prev.speed + (p.speed - prev.speed) * k,
                )
            prev = p
        return poses[-1]


class Coverage:
    """Сетка покрытия: клетка считается пройденной, если над ней прошла катушка в норме."""

    def __init__(self, area: list[tuple[float, float]], cell_m: float, coil_width_m: float) -> None:
        self.cell = cell_m
        self.radius = coil_width_m / 2
        xs = [p[0] for p in area]
        ys = [p[1] for p in area]
        self.inside: set[tuple[int, int]] = set()
        for i in range(math.floor(min(xs) / cell_m), math.ceil(max(xs) / cell_m) + 1):
            for j in range(math.floor(min(ys) / cell_m), math.ceil(max(ys) / cell_m) + 1):
                if point_in_polygon((i + 0.5) * cell_m, (j + 0.5) * cell_m, area):
                    self.inside.add((i, j))
        self.covered: set[tuple[int, int]] = set()

    def mark(self, east: float, north: float) -> None:
        r = self.radius
        c = self.cell
        for i in range(math.floor((east - r) / c), math.floor((east + r) / c) + 1):
            for j in range(math.floor((north - r) / c), math.floor((north + r) / c) + 1):
                cx, cy = (i + 0.5) * c, (j + 0.5) * c
                if (cx - east) ** 2 + (cy - north) ** 2 <= r * r and (i, j) in self.inside:
                    self.covered.add((i, j))

    @property
    def percent(self) -> float:
        if not self.inside:
            return 0.0
        return 100.0 * len(self.covered) / len(self.inside)


class SignalProcessor:
    """Онлайн-обработка одного поиска."""

    BASELINE_ALPHA = 1 / 40  # ≈ 2 с при 20 Гц
    NOISE_ALPHA = 1 / 120
    HIT_SIGMAS = 6.0
    HIT_MIN = 0.12
    SHIFT_SAMPLES = 40  # ≈ 2 с непрерывного превышения = смена грунта
    MIN_HIT_SAMPLES = 3  # короче — выброс помехи (регуляторы моторов дают одиночные пики)
    ECHO_RATIO = 0.35  # проход слабее трети соседнего — боковой отголосок того же предмета

    def __init__(
        self,
        frame: LocalFrame,
        profile: DeviceProfile,
        area: list[LatLon],
        first_find_id: int = 1,
    ) -> None:
        self.frame = frame
        self.profile = profile
        self.poses = PoseBuffer()
        self.coil_height: tuple[int, float] | None = None
        self.yaw_rate = 0.0
        self.recording = False
        self.baseline: float | None = None
        self._high = 0
        self.noise = 0.05
        self.pending: deque[RawSample] = deque()
        self.current_hit: _PassHit | None = None
        self.finds: list[FindState] = []
        self._next_id = first_find_id
        local_area = [frame.to_local(p.lat, p.lon) for p in area]
        self.coverage = Coverage(local_area, max(0.15, profile.lane_spacing_m / 1.5), profile.coil_width_m)

    # ---------- входы ----------
    def on_pose(self, t_ms: int, lat: float, lon: float, heading_deg: float, speed: float) -> None:
        e, n = self.frame.to_local(lat, lon)
        self.poses.add(Pose(t_ms, e, n, math.radians(heading_deg), speed))

    def on_coil_height(self, t_ms: int, meters: float) -> None:
        self.coil_height = (t_ms, meters)

    def on_yaw_rate(self, rad_s: float) -> None:
        self.yaw_rate = rad_s

    def on_sample(self, sample: RawSample) -> tuple[list[GeoSample], list[FindState]]:
        """Возвращает привязанные измерения и находки, изменившиеся на этом шаге."""
        self.pending.append(sample)
        out: list[GeoSample] = []
        changed: list[FindState] = []
        latest = self.poses.latest_t
        while self.pending:
            s = self.pending[0]
            if latest is not None and s.t_ms < latest - 30_000:
                self.pending.clear()  # после перезагрузки старые метки времени бесполезны
                break
            if latest is None or s.t_ms > latest:
                if len(self.pending) > 40:
                    self.pending.popleft()  # позы давно нет — выбрасываем
                    continue
                break
            self.pending.popleft()
            geo = self._georef(s)
            if geo is None:
                continue
            out.append(geo)
            find = self._detect(geo)
            if find is not None:
                changed.append(find)
        return out, changed

    # ---------- внутреннее ----------
    def _coil_h(self, t_ms: int) -> float | None:
        if self.profile.kind == "rover":
            return self.profile.coil_target_height_m
        if self.coil_height is None or abs(self.coil_height[0] - t_ms) > 600:
            return None
        return self.coil_height[1]

    def _georef(self, s: RawSample) -> GeoSample | None:
        pose = self.poses.at(s.t_ms)
        if pose is None:
            return None
        fwd = self.profile.coil_forward_m
        east = pose.east + fwd * math.sin(pose.yaw)
        north = pose.north + fwd * math.cos(pose.yaw)
        coil_h = self._coil_h(s.t_ms)
        p = self.profile
        valid = (
            self.recording
            and coil_h is not None
            and coil_h <= p.coil_max_height_m
            and 0.3 * p.search_speed_mps <= pose.speed <= 1.8 * p.search_speed_mps
            and abs(self.yaw_rate) < math.radians(25)
        )
        # Фон грунта отслеживаем всегда, когда катушка на рабочей высоте и движется — и на
        # перелёте к полосе тоже: иначе к началу полосы фон устаревает и даёт ложные находки.
        # На стоянках и разворотах на месте не учимся: VLF-катушка над неподвижным предметом
        # «впитала» бы его в фон.
        moving = pose.speed >= 0.3 * p.search_speed_mps
        tracking = coil_h is not None and coil_h <= p.coil_max_height_m and moving
        if self.baseline is None:
            if not tracking:
                return self._geo(s, east, north, coil_h, 0.0, False)
            self.baseline = s.signal
        excess = s.signal - self.baseline
        if tracking:
            if excess < 3 * self.noise:
                self.baseline += self.BASELINE_ALPHA * (s.signal - self.baseline)
                self.noise += self.NOISE_ALPHA * (abs(excess) - self.noise)
                self.noise = max(0.02, self.noise)
                self._high = 0
            elif valid:
                # Превышение на полосе дольше ~2 с — это сменился грунт, а не предмет: предмет
                # катушка проходит за доли секунды. Переносим фон, начатый всплеск отбрасываем.
                self._high += 1
                if self._high > self.SHIFT_SAMPLES:
                    self.baseline = s.signal
                    self.current_hit = None
                    self._high = 0
                    excess = 0.0
        return self._geo(s, east, north, coil_h, excess, valid)

    def _geo(
        self, s: RawSample, east: float, north: float, coil_h: float | None, excess: float, valid: bool
    ) -> GeoSample:
        ll = self.frame.to_latlon(east, north)
        if valid:
            self.coverage.mark(east, north)
        return GeoSample(
            s.t_ms, ll.lat, ll.lon, east, north, coil_h, s.signal, max(0.0, excess), s.target_id, valid
        )

    def _detect(self, g: GeoSample) -> FindState | None:
        threshold = max(self.HIT_SIGMAS * self.noise, self.HIT_MIN)
        if g.valid and g.excess > threshold:
            if self.current_hit is None:
                self.current_hit = _PassHit()
            self.current_hit.points.append((g, g.excess))
            return None
        if self.current_hit is not None and (not g.valid or g.excess < threshold / 2):
            hit = self.current_hit
            self.current_hit = None
            # Предмет катушка проходит за несколько измерений; 1–2 подряд — выброс помехи.
            if len(hit.points) >= self.MIN_HIT_SAMPLES:
                return self._merge(hit)
        return None

    def _merge(self, hit: _PassHit) -> FindState | None:
        peak_g, peak = max(hit.points, key=lambda p: p[1])
        half = [g for g, ex in hit.points if ex >= peak / 2]
        width = math.dist((half[0].east, half[0].north), (half[-1].east, half[-1].north))
        # Аномалия намного шире следа катушки — это пятно грунта, а не предмет.
        if width > max(1.2, 4 * self.profile.coil_width_m):
            return None
        width += 0.05  # шаг измерений
        tids = [(g.target_id, ex) for g, ex in hit.points if g.target_id >= 0 and ex >= peak / 2]
        depth = self._depth_cm(width, peak_g.coil_h)
        radius = max(0.5, self.profile.coil_width_m * 1.5)
        best: FindState | None = None
        best_d = math.inf
        for f in self.finds:
            d = math.hypot(f.east - peak_g.east, f.north - peak_g.north)
            # Сильный неглубокий предмет слышен и с соседних полос — слабым «отголоском» сбоку.
            # Такой отголосок рядом с сильной находкой (или наоборот) — тот же предмет.
            echo = d <= 2.5 * radius and min(peak, f.peak) < self.ECHO_RATIO * max(peak, f.peak)
            if (d <= radius or echo) and d < best_d:
                best, best_d = f, d
        if best is not None:
            f = best
            w = peak * peak  # координата тянется к самому сильному проходу — он ближе всех
            f.east = (f.east * f.weight + peak_g.east * w) / (f.weight + w)
            f.north = (f.north * f.weight + peak_g.north * w) / (f.weight + w)
            f.weight += w
            if peak >= f.peak:
                f.depth_cm = depth  # глубину честнее всего оценивает проход прямо над предметом
            f.peak = max(f.peak, peak)
            f.passes += 1
            f.tids.extend(tids)
            self._finalize(f)
            return f
        f = FindState(
            id=self._next_id,
            east=peak_g.east,
            north=peak_g.north,
            lat=0.0,
            lon=0.0,
            peak=peak,
            target_id=None,
            passes=1,
            depth_cm=depth,
            category="",
            strength=0,
            weight=peak * peak,
            tids=list(tids),
        )
        self._next_id += 1
        self.finds.append(f)
        self._finalize(f)
        return f

    def _finalize(self, f: FindState) -> None:
        ll = self.frame.to_latlon(f.east, f.north)
        f.lat, f.lon = ll.lat, ll.lon
        if f.tids:
            ordered = sorted(f.tids)
            total = sum(w for _, w in ordered)
            acc = 0.0
            for tid, w in ordered:
                acc += w
                if acc >= total / 2:
                    f.target_id = round(tid)
                    break
        f.category = category_for(f.target_id)
        f.strength = strength_pct(f.peak)

    def _depth_cm(self, width_m: float, coil_h: float | None) -> int | None:
        """Глубина по ширине аномалии: для отклика (a²/(a²+z²+r²))³ ширина на половине
        высоты W ≈ 1,02·√(a² + z²), где z — от катушки до предмета."""
        if coil_h is None:
            return None
        a = self.profile.coil_width_m / 2
        z2 = (width_m / 1.02) ** 2 - a * a
        if z2 <= 0:
            return 0
        depth = math.sqrt(z2) - coil_h
        return int(5 * round(max(0.0, min(0.4, depth)) * 100 / 5))

    @property
    def median_noise(self) -> float:
        return statistics.fmean([self.noise])
