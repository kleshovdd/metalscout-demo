"""Что означает ID цели: шкала 0–99, как на дисплеях VLF-металлоискателей.

Шкала зависит от модели детектора; границы ниже — типичные и уточняются после калибровки
на эталонных мишенях.
"""

from __future__ import annotations

import math

from metalscout.i18n import tr

CATEGORIES: tuple[tuple[int, int, str, str], ...] = (
    (0, 15, "Iron", "Железо"),
    (16, 30, "Foil, small bits", "Фольга, мелочь"),
    (31, 45, "Small non-ferrous metal", "Мелкий цветной металл"),
    (46, 65, "Aluminium, nickel", "Алюминий, никель"),
    (66, 99, "Copper, brass, silver", "Медь, латунь, серебро"),
)


def category_for(target_id: int | None) -> str:
    """Что за металл по ID цели — на языке интерфейса (поэтому из базы не читается, а считается)."""
    if target_id is not None:
        for lo, hi, en, ru in CATEGORIES:
            if lo <= target_id <= hi:
                return tr(en, ru)
    return tr("Unknown", "Не определено")


def excess_from_strength(strength: int) -> float:
    """Обратное к strength_pct (приблизительно) — для находок, восстановленных из базы."""
    return (math.expm1(strength / 100 * math.log1p(8 * 15))) / 8


def strength_pct(excess: float) -> int:
    """Сила сигнала для человека: 0–100, логарифмическая шкала."""
    return max(1, min(100, round(100 * math.log1p(excess * 8) / math.log1p(8 * 15))))
