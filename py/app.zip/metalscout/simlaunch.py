"""Демо-режим: запуск симулятора устройства отдельным процессом.

Программа не знает, что на том конце симулятор: она подключается к нему по MAVLink/UDP
так же, как к настоящему устройству по Wi-Fi-мосту. Этот модуль только запускает процесс
и проксирует «руки человека» (поменять батарею, уронить связь) в пульт симулятора.
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
import urllib.request
from typing import Any

from metalscout.device.profiles import DeviceKind


class SimulatorProcess:
    def __init__(self, udp_port: int, control_port: int) -> None:
        self.udp_port = udp_port
        self.control_port = control_port
        self._proc: subprocess.Popen[bytes] | None = None
        self.kind: DeviceKind | None = None

    @property
    def running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    @property
    def url(self) -> str:
        return f"udpin:127.0.0.1:{self.udp_port}"

    def start(self, kind: DeviceKind, speedup: float) -> None:
        self.stop()
        self.kind = kind
        self._proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "metalscout_sim",
                "--vehicle",
                kind.value,
                "--target",
                f"udpout:127.0.0.1:{self.udp_port}",
                "--control-port",
                str(self.control_port),
                "--speedup",
                str(speedup),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def stop(self) -> None:
        if self._proc is not None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._proc.kill()
            self._proc = None
            self.kind = None

    async def call(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        def do() -> Any:
            data = json.dumps(body or {}).encode() if method == "POST" else None
            req = urllib.request.Request(
                f"http://127.0.0.1:{self.control_port}/{path}",
                data=data,
                method=method,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                return json.loads(resp.read() or b"null")

        return await asyncio.to_thread(do)
