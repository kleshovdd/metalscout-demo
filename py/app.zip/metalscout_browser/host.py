"""Стенд в браузере: настоящая программа + настоящий симулятор в одном цикле asyncio.

В браузере (Pyodide) нет процессов, потоков и сокетов. Поэтому стенд:

- запускает симулятор не процессом, а задачей asyncio (`Simulator.tick` по таймеру);
- соединяет программу и симулятор MAVLink-проводом в памяти (`mem:gcs` ↔ `mem:vehicle`);
- читает канал задачей asyncio вместо потока (`MavlinkLink` в браузере);
- отвечает на запросы интерфейса, вызывая ASGI-приложение FastAPI напрямую (`Bridge`).

Код программы (`metalscout`) при этом не меняется и не знает, где он работает.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time
from collections.abc import Callable, MutableMapping
from pathlib import Path
from typing import Any

import anyio.to_thread

os.environ.setdefault("MAVLINK20", "1")  # как у программы и симулятора: до импорта pymavlink

from pymavlink import mavutil

import metalscout.api.app as app_module
from metalscout.config import Settings
from metalscout.device import link as link_module
from metalscout.device.profiles import DeviceKind
from metalscout_browser.memlink import Wire
from metalscout_sim.server import SimOptions, Simulator

log = logging.getLogger(__name__)

# Точка старта демо — та же, что у симулятора по умолчанию.
HOME_LAT, HOME_LON, HOME_ALT = 55.70590, 37.37030, 180.0
TICK_S = 0.02

WIRE = Wire()


# ---------- то, чего нет в браузере ----------
async def _inline_to_thread[T](fn: Callable[..., T], /, *args: Any, **kwargs: Any) -> T:
    """Потоков нет — выполняем сразу. В стенде это только быстрые открытия/закрытия канала."""
    return fn(*args, **kwargs)


async def _inline_run_sync[T](fn: Callable[..., T], *args: Any, **_: Any) -> T:
    """anyio.to_thread.run_sync без потоков: FastAPI так вызывает синхронные зависимости."""
    return fn(*args)


_original_connection = mavutil.mavlink_connection


def _connection(device: str, *args: Any, **kwargs: Any) -> Any:
    if device.startswith("mem:"):
        return WIRE.connect(
            device,
            source_system=int(kwargs.get("source_system", 255)),
            source_component=int(kwargs.get("source_component", 0)),
        )
    return _original_connection(device, *args, **kwargs)


class BrowserLink(link_module.MavlinkLink):
    """Тот же канал, но чтение и heartbeat — задачи asyncio, а не потоки."""

    _tasks: list[asyncio.Task[None]]

    def open(self) -> None:
        try:
            self._conn = mavutil.mavlink_connection(
                self.url,
                baud=self.baud,
                source_system=link_module.GCS_SYSID,
                source_component=link_module.GCS_COMPID,
                autoreconnect=True,
            )
        except Exception as exc:
            raise link_module.LinkError(f"Не удалось открыть {self.url}: {exc}") from exc
        self._tasks = [
            self._loop.create_task(self._read_loop()),
            self._loop.create_task(self._heartbeat_loop()),
        ]

    def close(self) -> None:
        for task in getattr(self, "_tasks", []):
            task.cancel()
        self._tasks = []
        if self._conn is not None:
            with contextlib.suppress(Exception):
                self._conn.close()
            self._conn = None

    async def _read_loop(self) -> None:
        while self._conn is not None:
            while True:
                try:
                    msg = self._conn.recv_match(blocking=False)
                except Exception:
                    log.warning("Ошибка чтения MAVLink", exc_info=True)
                    break
                if msg is None:
                    break
                if msg.get_type() == "BAD_DATA":
                    continue
                self.last_rx = time.monotonic()
                self._on_message(msg)
            await asyncio.sleep(0.01)

    async def _heartbeat_loop(self) -> None:
        ml = mavutil.mavlink
        while True:
            await asyncio.sleep(1.0)
            with contextlib.suppress(Exception):
                self.send(
                    lambda m: m.heartbeat_send(
                        ml.MAV_TYPE_GCS, ml.MAV_AUTOPILOT_INVALID, 0, 0, ml.MAV_STATE_ACTIVE
                    )
                )


class BrowserSimulator:
    """Замена `SimulatorProcess`: тот же интерфейс, симулятор — задача asyncio."""

    def __init__(self, udp_port: int = 0, control_port: int = 0) -> None:
        self._sim: Simulator | None = None
        self._task: asyncio.Task[None] | None = None
        self.kind: DeviceKind | None = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    @property
    def url(self) -> str:
        return "mem:gcs"

    def start(self, kind: DeviceKind, speedup: float) -> None:
        self.stop()
        self.kind = kind
        self._sim = Simulator(
            SimOptions(
                vehicle=kind.value,
                home_lat=HOME_LAT,
                home_lon=HOME_LON,
                home_alt=HOME_ALT,
                target="mem:vehicle",
                speedup=speedup,
                seed=7,
                control_port=0,
            )
        )
        self._task = asyncio.get_running_loop().create_task(self._run(self._sim))

    async def _run(self, sim: Simulator) -> None:
        last = time.monotonic()
        while True:
            await asyncio.sleep(TICK_S)
            now = time.monotonic()
            # Вкладка была в фоне — не догоняем минуты физики одним рывком.
            sim.tick(min(now - last, 0.25), now)
            last = now

    def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            self._task = None
        if self._sim is not None:
            with contextlib.suppress(Exception):
                self._sim.conn.close()
            self._sim = None
        self.kind = None

    async def call(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        sim = self._sim
        if sim is None:
            raise OSError("Симулятор не запущен")
        if method == "GET" and path == "state":
            return dict(sim.snapshot)
        if method == "GET" and path == "truth":
            return sim.truth()
        sim.actions.put((path, body or {}))
        return {"ok": True}


def install() -> None:
    """Подменить в загруженных модулях то, чего нет в браузере."""
    import metalscout.device.ardupilot as ardupilot_module

    setattr(asyncio, "to_thread", _inline_to_thread)  # noqa: B010 — подмена модуля, не опечатка
    setattr(anyio.to_thread, "run_sync", _inline_run_sync)  # noqa: B010
    setattr(mavutil, "mavlink_connection", _connection)  # noqa: B010
    setattr(link_module, "MavlinkLink", BrowserLink)  # noqa: B010
    setattr(ardupilot_module, "MavlinkLink", BrowserLink)  # noqa: B010
    setattr(app_module, "SimulatorProcess", BrowserSimulator)  # noqa: B010


# ---------- мост «интерфейс → API» без сети ----------
class Bridge:
    """Вызывает ASGI-приложение напрямую: запросы и WebSocket интерфейса идут сюда."""

    def __init__(self, data_dir: Path) -> None:
        install()
        settings = Settings(
            data_dir=data_dir, web_dist=None, sim_udp_port=0, sim_control_port=0, demo_only=True
        )
        self.app = app_module.create_app(settings)
        self._lifespan: contextlib.AbstractAsyncContextManager[Any] | None = None
        self._sockets: dict[int, asyncio.Queue[dict[str, Any]]] = {}
        self._next_socket = 1

    async def start(self) -> None:
        self._lifespan = self.app.router.lifespan_context(self.app)
        await self._lifespan.__aenter__()

    async def stop(self) -> None:
        if self._lifespan is not None:
            await self._lifespan.__aexit__(None, None, None)

    def _scope(self, kind: str, path: str) -> dict[str, Any]:
        raw, _, query = path.partition("?")
        return {
            "type": kind,
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "scheme": "http" if kind == "http" else "ws",
            "path": raw,
            "raw_path": raw.encode(),
            "query_string": query.encode(),
            "root_path": "",
            "headers": [(b"host", b"demo.local"), (b"content-type", b"application/json")],
            "client": ("127.0.0.1", 0),
            "server": ("demo.local", 80),
            "state": {},
        }

    async def http(self, method: str, path: str, body: str | None) -> dict[str, Any]:
        scope = self._scope("http", path)
        scope["method"] = method
        payload = (body or "").encode()
        sent = False
        status = 500
        headers: list[tuple[str, str]] = []
        chunks: list[bytes] = []

        async def receive() -> dict[str, Any]:
            nonlocal sent
            if not sent:
                sent = True
                return {"type": "http.request", "body": payload, "more_body": False}
            await asyncio.Future()  # клиент «не отключается»
            return {"type": "http.disconnect"}

        async def send(message: MutableMapping[str, Any]) -> None:
            nonlocal status, headers
            if message["type"] == "http.response.start":
                status = int(message["status"])
                headers = [(k.decode(), v.decode()) for k, v in message.get("headers", [])]
            elif message["type"] == "http.response.body":
                chunks.append(bytes(message.get("body", b"")))

        await self.app(scope, receive, send)
        return {"status": status, "headers": headers, "body": b"".join(chunks)}

    def ws_open(self, on_text: Callable[[str], Any]) -> int:
        """Открыть «WebSocket» интерфейса; события приходят в on_text строкой JSON."""
        sid = self._next_socket
        self._next_socket += 1
        inbox: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        inbox.put_nowait({"type": "websocket.connect"})
        self._sockets[sid] = inbox
        closed = False

        async def receive() -> dict[str, Any]:
            return await inbox.get()

        async def send(message: MutableMapping[str, Any]) -> None:
            if closed or sid not in self._sockets:
                raise RuntimeError("WebSocket закрыт")  # приложение ловит и отписывается
            if message["type"] == "websocket.send":
                text = message.get("text")
                if text is None and message.get("bytes") is not None:
                    text = bytes(message["bytes"]).decode()
                if text is not None:
                    on_text(text)

        async def run() -> None:
            try:
                await self.app(self._scope("websocket", "/api/ws"), receive, send)
            finally:
                self._sockets.pop(sid, None)

        asyncio.get_running_loop().create_task(run())
        return sid

    def ws_close(self, sid: int) -> None:
        inbox = self._sockets.pop(sid, None)
        if inbox is not None:
            inbox.put_nowait({"type": "websocket.disconnect", "code": 1000})


async def create_bridge(data_dir: str = "/home/pyodide/data") -> Bridge:
    path = Path(data_dir)
    path.mkdir(parents=True, exist_ok=True)  # noqa: ASYNC240 — в браузере это память, не диск
    bridge = Bridge(path)
    await bridge.start()
    return bridge
