"""MAVLink-канал в памяти: пара соединённых «проводов» вместо UDP."""

from __future__ import annotations

from typing import Any

from pymavlink import mavutil


class MemoryPort(mavutil.mavfile):  # type: ignore[misc]
    """Один конец провода. Байты, записанные сюда, читает парный конец."""

    def __init__(self, address: str, source_system: int, source_component: int) -> None:
        self.inbox = bytearray()
        self.peer: MemoryPort | None = None
        self.connected = True
        super().__init__(None, address, source_system=source_system, source_component=source_component)

    def recv(self, n: int | None = None) -> bytes:
        if not self.inbox:
            return b""
        size = len(self.inbox) if n is None else min(n, len(self.inbox))
        chunk = bytes(self.inbox[:size])
        del self.inbox[:size]
        return chunk

    def write(self, buf: Any) -> None:
        if self.connected and self.peer is not None and self.peer.connected:
            self.peer.inbox.extend(buf)

    def close(self, n: Any = None) -> None:
        self.connected = False
        self.inbox.clear()


class Wire:
    """Провод с двумя концами по именам: `mem:gcs` (программа) и `mem:vehicle` (симулятор)."""

    def __init__(self) -> None:
        self.ends: dict[str, MemoryPort] = {}

    def connect(self, url: str, source_system: int, source_component: int) -> MemoryPort:
        port = MemoryPort(url, source_system, source_component)
        self.ends[url] = port
        other = self.ends.get("mem:vehicle" if url == "mem:gcs" else "mem:gcs")
        if other is not None:
            port.peer, other.peer = other, port
        return port
